# Trocas e Devoluções, Guia do Vendedor

## Objetivo e Âmbito

Este documento estabelece as diretrizes aplicáveis ao processo de trocas e devoluções dentro da plataforma. As regras aqui descritas se aplicam a todos os vendedores ativos cadastrados na plataforma, independentemente do porte ou categoria de produtos comercializados.

O cumprimento integral destas diretrizes é condição obrigatória para a manutenção da conta de vendedor. Não existe margem para interpretação parcial ou seletiva. Você aplica as regras na totalidade ou sua conta está sujeita às medidas previstas nos termos de uso da plataforma.

A plataforma reserva-se o direito de atualizar este documento sempre que necessário, comunicando os vendedores com antecedência razoável. Fique atento às notificações enviadas pelo painel.

---

## 1. Definições

Antes de qualquer coisa, leia com atenção o significado exato de cada termo usado neste guia. Interpretações fora das definições abaixo não serão aceitas como justificativa em disputas ou contestações.

**Devolução** indica o processo formal pelo qual o comprador solicita o retorno de um item adquirido na plataforma, com o objetivo de obter reembolso ou troca.

**Vendedor** indica a pessoa física ou jurídica cadastrada na plataforma para comercialização de produtos.

**Comprador** indica o usuário que realizou a compra do produto por meio da plataforma.

**Painel** indica a interface de gestão disponibilizada pela plataforma ao vendedor para acompanhamento de pedidos, notificações e ações relacionadas às suas vendas.

**Repasse** indica o valor devido ao vendedor pela plataforma referente a uma venda concluída, conforme a política de repasse vigente.

Guarde esses termos. Eles aparecem ao longo de todo este documento e têm significado técnico preciso.

---

## 2. Processo de Devolução

### 2.1 Solicitação pelo Comprador

Quando o comprador solicita a devolução, a plataforma registra o pedido automaticamente e notifica o vendedor por meio do painel. Você deve acessar o painel imediatamente para visualizar os detalhes da solicitação e entender o que está sendo pedido.

Todas as comunicações relativas ao processo de devolução devem ocorrer exclusivamente pelos canais oficiais da plataforma. Qualquer tentativa de resolver a situação fora desses canais coloca sua conta em risco e invalida eventuais argumentos de defesa em disputas posteriores.

### 2.2 Acompanhamento do Prazo de Postagem

Após a abertura da solicitação de devolução, você recebe a notificação no painel e passa a ser responsável por monitorar ativamente o andamento da postagem do item pelo comprador.

Fique atento a este ponto.

O não acompanhamento do prazo de postagem não isenta o vendedor das obrigações previstas neste documento. Ignorar a notificação não suspende o processo. O fluxo segue independentemente da sua ação, e as consequências recaem sobre você.

### 2.3 Recebimento e Conferência do Item

Recebido o item de volta, você confere o estado do produto com atenção. A conferência deve avaliar se o item retornou nas mesmas condições em que foi enviado ao comprador. Esse momento é crítico. Qualquer divergência identificada deve ser documentada com evidências antes de qualquer ação no painel.

Após a conferência, você confirma o recebimento no painel, liberando o fluxo de reembolso ao comprador. Esse registro no painel é obrigatório e deve ser realizado dentro do prazo indicado na notificação correspondente. O descumprimento desse prazo pode gerar penalidade automática de reputação.

### 2.4 Fluxo de Reembolso ao Comprador

A confirmação do recebimento pelo vendedor no painel inicia automaticamente o fluxo de reembolso ao comprador. A plataforma processa o reembolso conforme suas próprias regras de pagamento.

O vendedor não deve negociar diretamente com o comprador qualquer valor relacionado ao reembolso fora dos canais oficiais da plataforma. Essa conduta é considerada violação das políticas e pode resultar em suspensão imediata da conta.

---

## 3. Repasse ao Vendedor

A devolução do repasse ao vendedor segue a política de repasse vigente na plataforma.

Consulte a política de repasse para compreender os prazos e condições aplicáveis à reversão de valores em casos de devolução. A plataforma não antecipará repasses em situações em que o processo de devolução ainda esteja em andamento. Não adianta abrir chamado solicitando adiantamento enquanto o caso não estiver encerrado.

---

## 4. Recusa de Devolução

### 4.1 Condições para Recusa

Você pode recusar uma solicitação de devolução desde que apresente justificativa fundamentada e compatível com as políticas da plataforma. A recusa deve ser registrada formalmente no painel, com descrição clara do motivo. Registros vagos ou genéricos não serão considerados justificativa válida.

Situações que podem embasar uma recusa incluem as seguintes.

- Produto retornado com danos causados por uso indevido do comprador.
- Item devolvido fora do prazo estabelecido pelas políticas da categoria.
- Produto retornado incompleto, com partes ou acessórios faltando.
- Evidências documentadas de adulteração do item após a entrega.

Em todos os casos, as evidências precisam estar registradas no painel antes de você formalizar a recusa.

### 4.2 Penalidade por Recusa Injustificada

Devolução recusada sem justificativa gera penalidade de reputação ao vendedor. A penalidade de reputação pode impactar a visibilidade dos produtos do vendedor na plataforma, reduzindo o alcance das suas listagens e sua posição nos resultados de busca.

Recusas reiteradas sem justificativa podem resultar em medidas adicionais, conforme os termos de uso da plataforma. Essas medidas incluem suspensão temporária e, em casos graves, encerramento definitivo da conta.

Não arrisque sua reputação por uma recusa sem base. Se você tem razão, documente e registre. Se não tem, aceite o processo.

---

## 5. Exceções e Casos Especiais

Produtos que apresentem indícios de uso indevido após o retorno podem ter o processo de devolução contestado pelo vendedor mediante registro de evidências no painel. A plataforma analisará cada caso de forma individualizada. Não existe garantia de resultado favorável sem documentação adequada.

Itens pertencentes a categorias com regras específicas de devolução estão sujeitos às condições particulares descritas nas políticas de cada categoria. Verifique as regras da sua categoria antes de agir.

---

## 6. Resumo das Obrigações do Vendedor

Use esta lista como referência rápida no dia a dia.

- Acessar o painel assim que receber notificação de solicitação de devolução.
- Monitorar ativamente o prazo de postagem do item pelo comprador.
- Conferir o estado do produto no momento do recebimento.
- Registrar o recebimento no painel dentro do prazo indicado na notificação.
- Documentar evidências antes de registrar qualquer recusa.
- Manter todas as comunicações exclusivamente pelos canais oficiais da plataforma.
- Consultar a política de repasse para entender os prazos de reversão de valores.

O descumprimento de qualquer item desta lista pode gerar penalidade de reputação ou medidas adicionais conforme os termos de uso da plataforma.

---

## 7. Disposições Gerais

Este documento integra o conjunto de políticas da plataforma e deve ser interpretado em conjunto com os demais termos aplicáveis aos vendedores. Em caso de conflito entre este documento e outro instrumento da plataforma, prevalecerá a disposição mais específica.

A plataforma poderá revisar este guia periodicamente. Atualizações serão comunicadas com antecedência razoável pelo painel. É responsabilidade do vendedor manter-se informado sobre as versões vigentes das políticas.

**Versão** 1.0
**Data de vigência** a definir pela plataforma
