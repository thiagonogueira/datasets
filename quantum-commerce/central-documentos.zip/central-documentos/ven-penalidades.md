# Tabela de penalidades do vendedor

## O que este guia cobre

Este documento define as regras de conduta obrigatórias para todo vendedor parceiro ativo na plataforma. Leia com atenção antes de realizar qualquer venda. O desconhecimento das regras não isenta o vendedor de penalidade.

---

## Tabela de penalidades

A tabela abaixo é o documento de referência oficial. Os valores, prazos e termos aqui listados são fixos e não estão sujeitos a negociação individual.

| infração | penalidade |
|---|---|
| atraso reiterado de expedição | rebaixamento de reputação |
| item divergente confirmado | multa de 20% do valor da venda |
| imitação confirmada | suspensão de 90 dias |
| má-fé confirmada em disputa | banimento |

---

## Entendendo cada infração

### Atraso reiterado de expedição

Atraso pontual pode acontecer. O problema começa quando o padrão se repete.

A plataforma monitora o histórico de expedição de cada vendedor de forma contínua. Quando o sistema identifica um padrão de atrasos recorrentes, o perfil do vendedor recebe rebaixamento de reputação automático. Esse rebaixamento afeta diretamente a visibilidade dos seus anúncios nas buscas, reduz a prioridade nas vitrines e pode impedir o acesso a programas de destaque oferecidos pela plataforma. Recuperar a reputação exige um período de desempenho consistente, sem garantia de prazo fixo para reversão.

Expedir dentro do prazo combinado com o comprador não é diferencial. É obrigação básica.

### Item divergente confirmado

Quando o comprador recebe um produto diferente do anunciado e a plataforma confirma a divergência após análise, o vendedor recebe multa de 20% do valor da venda. O valor é descontado diretamente do saldo disponível na conta do vendedor, sem etapa adicional de cobrança.

Atenção aos pontos que mais geram divergência confirmada. - Descrição do produto incompleta ou imprecisa
- Fotos que não representam o item real enviado
- Variação de cor, tamanho ou modelo diferente do selecionado pelo comprador
- Quantidade inferior à anunciada

Revise cada anúncio antes de publicar. Revise o pedido antes de embalar. Revise o pacote antes de fechar.

### Imitação confirmada

Vender produto que imita marca registrada ou que reproduz item protegido sem autorização é infração grave. Quando a plataforma confirma a venda de imitação, o vendedor recebe suspensão de 90 dias imediata, sem período de aviso prévio.

Durante os 90 dias de suspensão, todos os anúncios do vendedor ficam inativos, nenhuma nova venda pode ser realizada e o saldo fica retido conforme as regras de proteção ao comprador vigentes na plataforma. O vendedor pode apresentar defesa dentro do prazo informado na notificação oficial, mas a suspensão permanece ativa durante a análise.

Não publique nenhum item sem ter certeza absoluta da sua procedência e da sua regularidade legal.

### Má-fé confirmada em disputa

Esta é a infração mais grave do sistema.

Quando a plataforma identifica e confirma que o vendedor agiu com má-fé em uma disputa, seja fornecendo informações falsas, manipulando evidências ou tentando prejudicar o comprador de forma deliberada, a consequência é banimento. O banimento encerra permanentemente o acesso do vendedor à plataforma, incluindo todos os perfis e contas associados ao mesmo documento de identificação.

Não existe recurso padrão após banimento confirmado. O vendedor recebe notificação formal com os fundamentos da decisão.

---

## Como evitar penalidades

Siga esta lista antes de cada etapa do processo de venda.

Antes de publicar o anúncio. - Confirme que o produto é original e tem procedência comprovável
- Escreva a descrição com todas as informações relevantes
- Use fotos reais do item que será enviado

Antes de expedir o pedido. - Confira o produto, a quantidade e a variação selecionada pelo comprador
- Embale com segurança para evitar avaria no transporte
- Registre o código de rastreamento e insira na plataforma no prazo

Durante uma disputa. - Responda dentro do prazo informado na notificação
- Forneça apenas informações verdadeiras e documentadas
- Não tente contato fora dos canais oficiais da plataforma para pressionar o comprador

---

## Processo de notificação

Toda penalidade aplicada gera notificação automática no painel do vendedor. A notificação informa o tipo de infração, a penalidade aplicada e, quando aplicável, o prazo para apresentação de defesa. O vendedor é responsável por acompanhar as notificações regularmente. A plataforma não garante envio por outros canais além do painel oficial.

---

## Ponto final

As regras desta tabela existem para proteger compradores e para manter a integridade do ambiente de vendas. Vendedores que operam com transparência e responsabilidade não têm motivo para se preocupar com nenhuma das penalidades listadas aqui. Vendedores que tentam burlar o sistema encontrarão as consequências descritas acima aplicadas de forma direta e sem exceção.
