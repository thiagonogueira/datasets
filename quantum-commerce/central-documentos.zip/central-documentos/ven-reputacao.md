# Programa de reputação do vendedor

## O que é reputação

A plataforma mede o desempenho de cada vendedor parceiro por meio de um indicador chamado reputação. Esse indicador combina quatro fatores principais. prazo de expedição, taxa de disputa, taxa de devolução e avaliação dos compradores. O resultado define o nível do vendedor e determina diretamente as condições de operação dentro da plataforma.

Entenda isso como uma regra central do seu negócio aqui.

---

## Por que reputação importa para você

Vendedores com reputação alta recebem dois benefícios diretos e imediatos.

- Destaque na busca (seus anúncios aparecem antes dos concorrentes com nível inferior)
- Taxas menores cobradas pela plataforma sobre cada venda concluída

Vendedores com reputação baixa enfrentam restrições operacionais sérias. O principal impacto é a limitação do volume de anúncios ativos permitidos na conta. Menos anúncios ativos significa menos visibilidade, menos vendas e menos receita. Não existe caminho alternativo para contornar essa limitação enquanto a reputação estiver baixa.

---

## Os quatro fatores que formam a reputação

Cada fator tem peso no cálculo final do indicador. Nenhum deles pode ser ignorado.

**1. Prazo de expedição**
O tempo entre a confirmação do pagamento e a postagem do produto no serviço de entrega. Expedições fora do prazo comprometem diretamente esse fator.

**2. Taxa de disputa**
A proporção de pedidos que resultam em abertura de reclamação formal pelo comprador. Disputas abertas indicam problemas de atendimento, produto ou entrega.

**3. Taxa de devolução**
A proporção de pedidos em que o comprador solicita e conclui a devolução do produto. Devoluções frequentes sinalizam inconsistência entre o anúncio e o produto entregue.

**4. Avaliação dos compradores**
A nota atribuída pelo comprador ao final da transação. Avaliações baixas acumuladas puxam o indicador geral para baixo de forma consistente.

---

## Como operar para manter reputação alta

Siga estas práticas sem exceção.

- Poste o produto dentro do prazo de expedição estabelecido para a sua categoria
- Descreva o produto no anúncio exatamente como ele é, sem omitir defeitos ou diferenças de versão
- Responda mensagens do comprador antes que o problema escale para disputa formal
- Embale o produto de forma adequada para evitar avarias no transporte
- Atualize o estoque regularmente para não vender produto indisponível

Vender produto diferente do anunciado é a causa mais comum de disputa e devolução ao mesmo tempo. Corrija anúncios imprecisos antes de receber o próximo pedido.

---

## Aviso de penalidade

Reputação baixa não é apenas uma notificação informativa. A plataforma aplica restrições automáticas e progressivas conforme o indicador cai.

A primeira consequência é a limitação do número de anúncios ativos permitidos na conta. A segunda consequência, em casos de queda severa, é a suspensão temporária da capacidade de criar novos anúncios. A terceira consequência, em situações de reincidência ou violação grave, é o encerramento da conta sem possibilidade de reativação.

Nenhuma dessas penalidades exige aprovação manual antes de ser aplicada. O sistema age de forma automática com base nos indicadores medidos.

---

## Expedição

Esse é o fator que você controla com mais facilidade e que tem impacto imediato na reputação.

Poste no prazo.

Se houver qualquer impedimento operacional (falta de estoque, problema com embalagem, ausência do responsável pela postagem), pause o anúncio antes de receber novos pedidos. Receber um pedido que não pode ser expedido no prazo é pior do que não receber o pedido.

---

## Disputas e como evitá-las

Uma disputa é aberta quando o comprador não consegue resolver o problema diretamente com o vendedor. A plataforma intervém e o histórico da disputa fica registrado na conta.

Para evitar disputas. - Responda toda mensagem de reclamação no menor tempo possível
- Ofereça solução antes que o comprador precise escalar
- Em caso de produto com defeito, combine a devolução ou reenvio diretamente com o comprador sem esperar a abertura formal de disputa
- Não ignore mensagens de compradores insatisfeitos esperando que o problema se resolva sozinho

Disputas resolvidas ainda contam negativamente. A melhor disputa é a que nunca foi aberta.

---

## Devoluções

Taxa de devolução alta indica problema sistemático, não episódico. Se mais de um comprador está devolvendo o mesmo produto, o problema está no anúncio ou no produto em si.

Revise o anúncio. Verifique se as fotos mostram o produto real. Confirme se a descrição corresponde ao que está sendo enviado. Cheque se o produto está dentro das especificações declaradas.

Devolução resolvida com agilidade minimiza o impacto na avaliação do comprador, mas não elimina o impacto na taxa de devolução. Os dois indicadores são medidos de forma separada.

---

## Avaliação dos compradores

Avaliação baixa é consequência, não causa. Ela reflete o que aconteceu em todo o processo. anúncio, expedição, produto recebido e atendimento.

Não solicite avaliação positiva de forma forçada ou condicione qualquer benefício a ela. Essa prática viola as regras da plataforma e pode resultar em penalidade adicional independente da reputação.

---

## Resumo operacional

Você é responsável por cada um dos quatro fatores que formam a reputação. A plataforma mede, calcula e aplica as consequências de forma automática. Não há negociação sobre o indicador calculado.

Mantenha a reputação alta. Isso protege seus anúncios, reduz suas taxas e garante sua posição na busca.
