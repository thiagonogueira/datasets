# Lista de Itens de Venda Não Permitida (POL PRO 05)

## Preâmbulo e Propósito Normativo

Esta política estabelece as categorias de itens cuja oferta é expressamente vedada na plataforma, independentemente da modalidade de listagem utilizada pelo vendedor. As restrições aqui descritas aplicam-se a anúncios principais, brindes declarados, itens enviados em conjunto com outros produtos e qualquer outra forma de disponibilização ao comprador final. O cumprimento desta política é obrigatório para todos os vendedores cadastrados, sejam pessoas físicas ou jurídicas, em qualquer plano de adesão ativo na plataforma.

O âmbito de aplicação inclui o território nacional e abrange toda transação iniciada ou concluída por meio dos sistemas da plataforma. A plataforma se reserva o direito de aplicar as medidas previstas neste documento sempre que identificar, por meios automatizados ou por denúncia de terceiros, a oferta de item enquadrado nas categorias definidas na Seção 3.

A leitura deste documento deve ser feita em conjunto com a política POL COM 02, que disciplina o procedimento de conformidade aplicável às infrações identificadas, e com a política POL CAD 01, que regula as condições gerais de cadastro e manutenção de conta na plataforma. Em caso de conflito aparente entre disposições desta política e de outros instrumentos normativos internos, prevalece a interpretação mais restritiva quanto à permissibilidade do item ofertado.

---

## Definições

Para os fins desta política, os termos a seguir têm o significado indicado entre parênteses.

**Anúncio** (qualquer publicação criada por vendedor com a finalidade de oferecer produto ou serviço a compradores na plataforma, incluindo variações e kits).

**Item vedado** (produto, serviço, arquivo digital, credencial ou qualquer bem tangível ou intangível que se enquadre em ao menos uma das categorias listadas na Seção 3 deste documento).

**Brinde** (item adicional oferecido gratuitamente ao comprador em conjunto com o produto principal anunciado).

**Envio conjunto** (prática de incluir no pacote despachado ao comprador qualquer item não listado no anúncio original, independentemente de valor ou intenção declarada).

**Reincidência** (ocorrência de nova infração à presente política por vendedor que já tenha recebido ao menos uma notificação formal de remoção de anúncio nos últimos doze meses).

**Procedimento de conformidade** (conjunto de etapas internas de análise, notificação e sanção descrito na política POL COM 02, aplicável a infrações identificadas na plataforma).

---

## Seção 1. Disposições Gerais sobre Itens Vedados

1.1. A oferta dos itens descritos na Seção 3 é vedada na plataforma em qualquer circunstância. Não há exceção baseada em volume de vendas, histórico do vendedor ou categoria de conta. A vedação se aplica da mesma forma a vendedores novos e a vendedores com longa relação comercial com a plataforma, sem distinção de qualquer natureza.

1.2. A plataforma não reconhece como válida qualquer alegação de que o item vedado foi incluído sem conhecimento do vendedor. O vendedor é integralmente responsável pelo conteúdo de seus anúncios e pelo conteúdo dos pacotes que despacha aos compradores, incluindo brindes e itens de envio conjunto conforme definidos na seção de Definições deste documento.

1.3. A existência de legislação estadual ou municipal que permita determinado item em âmbito local não afasta a aplicação desta política. As regras aqui estabelecidas são independentes da legislação local e prevalecem para fins de uso da plataforma.

1.4. A plataforma poderá atualizar a lista de categorias vedadas contida na Seção 3 sempre que identificar risco à integridade do ambiente de negociação, à segurança dos compradores ou ao cumprimento de obrigações regulatórias aplicáveis. Atualizações serão comunicadas nos termos das Disposições Gerais ao final deste documento.

1.5. Nenhuma orientação prestada por canais não oficiais da plataforma, incluindo grupos de terceiros, fóruns externos ou comunicações não assinadas pela equipe de conformidade, tem o condão de afastar ou relativizar as vedações aqui estabelecidas.

---

## Seção 2. Responsabilidade do Vendedor

2.1. O vendedor é o único responsável por verificar, antes de publicar qualquer anúncio, se o item ofertado se enquadra em alguma das categorias vedadas descritas na Seção 3. A plataforma disponibiliza canais de consulta prévia para casos de dúvida, e o uso desses canais é recomendado antes da publicação de itens em categorias sensíveis.

2.2. A responsabilidade do vendedor se estende a itens incluídos como brinde ou enviados em conjunto com o produto principal. O fato de o item vedado não constar no anúncio principal não isenta o vendedor das sanções previstas nesta política, conforme o procedimento de conformidade descrito na política POL COM 02.

2.3. O vendedor que identificar, após a publicação, que seu anúncio contém item vedado deve removê-lo imediatamente por iniciativa própria. A remoção voluntária antes de qualquer notificação da plataforma será considerada circunstância atenuante na avaliação de reincidência, nos termos do procedimento de conformidade.

---

## Seção 3. Categorias de Itens Vedados

A oferta dos itens abaixo é vedada na plataforma, em anúncio, brinde ou envio conjunto.

### 3.1 Programas de Computador

3.1.1. São vedados na plataforma licenças e chaves de ativação de software, contas de acesso e assinaturas digitais revendidas.

3.1.2. A vedação desta categoria abrange tanto produtos digitais entregues por download quanto credenciais enviadas por mensagem ou e-mail. A origem do item não altera o enquadramento. Chaves de ativação obtidas de qualquer fonte e revendidas por terceiros se enquadram nesta categoria independentemente do software ao qual se referem.

3.1.3. O enquadramento nesta categoria independe de o vendedor ostentar qualquer relação contratual com o desenvolvedor do software, pois a comercialização por plataforma de marketplace não constitui canal de distribuição autorizado para esse tipo de produto salvo habilitação específica prevista na Seção 4.

### 3.2 Saúde

3.2.1. São vedados medicamentos, suplementos sem registro sanitário e produtos que exigem receita.

3.2.2. A ausência de registro sanitário válido e vigente junto ao órgão competente é condição suficiente para o enquadramento nesta categoria. Produtos que exigem receita médica ou odontológica são vedados mesmo que o vendedor afirme possuir autorização específica, pois a comercialização por plataforma de marketplace não é modalidade autorizada para esse tipo de produto.

3.2.3. A vedação alcança também produtos importados que, mesmo regularizados em território estrangeiro, não disponham de registro sanitário válido no Brasil na data da oferta.

### 3.3 Segurança

3.3.1. São vedados armas de qualquer natureza, réplicas de armas, inclusive de airsoft e de pressão, artefatos explosivos e itens de uso policial restrito.

3.3.2. A vedação abrange réplicas de armas independentemente do material de fabricação, do tamanho ou da finalidade declarada pelo vendedor. Itens classificados como decorativos ou colecionáveis que reproduzam a forma de armas reais se enquadram nesta categoria sem exceção.

3.3.3. Artefatos explosivos incluem fogos de artifício de qualquer classificação e dispositivos pirotécnicos em geral.

3.3.4. Acessórios cujo uso preponderante seja a modificação, adaptação ou potencialização de armas ou réplicas também se enquadram nesta categoria, ainda que comercializados de forma isolada e sem referência explícita à finalidade.

### 3.4 Animais e Derivados

3.4.1. São vedados animais vivos e produtos de fauna silvestre.

3.4.2. A vedação inclui ovos férteis de espécies silvestres, partes de animais protegidos e produtos cujo processo de fabricação envolva fauna silvestre, mesmo que o produto final não contenha material animal identificável.

### 3.5 Documentos e Dados

3.5.1. São vedados documentos oficiais, diplomas, dados pessoais e cadastros de terceiros.

3.5.2. A vedação abrange documentos originais e reproduções, bem como arquivos digitais que contenham dados pessoais de terceiros em qualquer formato. Listas de contatos, bases de e-mail e cadastros de qualquer natureza se enquadram nesta categoria, independentemente do meio de entrega ao comprador.

3.5.3. O enquadramento nesta categoria não exige que o vendedor tenha obtido os dados de forma ilícita. A mera comercialização de cadastros de terceiros, qualquer que seja a origem declarada, é suficiente para a caracterização da infração.

### 3.6 Cosméticos

3.6.1. São vedados cosméticos sem registro sanitário e produtos de marca sem procedência comprovada.

3.6.2. A ausência de nota fiscal de origem ou de documentação que comprove a cadeia de fornecimento é suficiente para o enquadramento na vedação de procedência não comprovada.

---

## Seção 4. Exceções e Casos Especiais

4.1. Não existem exceções automáticas às vedações listadas na Seção 3.

4.2. Vendedores que acreditem operar em situação especial podem submeter solicitação formal de análise ao time de conformidade da plataforma antes de publicar o anúncio. A análise não garante aprovação e não suspende a aplicação desta política durante o período de avaliação. A submissão da solicitação não confere ao vendedor qualquer direito subjetivo à habilitação, nem gera expectativa legítima de aprovação.

4.3. A plataforma pode, a seu exclusivo critério, criar programas específicos para categorias sensíveis com requisitos adicionais de habilitação. A existência de tais programas será comunicada oficialmente e não modifica as vedações desta política para vendedores não habilitados. Informações sobre programas vigentes podem ser obtidas nos canais oficiais de suporte da plataforma.

4.4. A habilitação concedida em programa específico é pessoal, intransferível e sujeita a revisão periódica. A transferência de titularidade de conta não transfere habilitações previamente concedidas, cabendo ao novo titular solicitar nova análise conforme o procedimento descrito nesta seção.

---

## Seção 5. Sanções

5.1. O anúncio que oferece item vedado é removido, e a reincidência leva à suspensão do vendedor, conforme o procedimento de conformidade descrito na política POL COM 02.

5.2. A remoção do anúncio ocorre sem aviso prévio e pode ser realizada de forma automatizada ou manual. O vendedor é notificado após a remoção por meio dos canais de comunicação cadastrados na plataforma.

5.3. A suspensão decorrente de reincidência pode ser temporária ou definitiva, a critério da equipe de conformidade, com base na gravidade das infrações acumuladas e no histórico geral do vendedor. A suspensão definitiva implica o encerramento de todos os anúncios ativos e a impossibilidade de criação de nova conta na plataforma.

5.4. A aplicação de sanção não exclui a responsabilidade civil ou administrativa do vendedor perante terceiros prejudicados pela oferta do item vedado, nem afasta eventuais comunicações a autoridades competentes nos casos em que a infração configure ilícito previsto em legislação federal.

5.5. O vendedor sancionado pode apresentar manifestação por meio dos canais de conformidade da plataforma, nos termos e prazos definidos na política POL COM 02. A apresentação de manifestação não suspende os efeitos da sanção aplicada durante o período de análise.

---

## Disposições Gerais

Esta política entra em vigor na data de sua publicação no painel de políticas da plataforma e substitui integralmente versões anteriores do documento identificado como POL PRO 05. Alterações futuras serão comunicadas com antecedência mínima por meio dos canais oficiais da plataforma.

**Versão** POL PRO 05.

---

## Notas Explicativas

**Nota 1.** A expressão "chaves de ativação", utilizada na Seção 3.1, abrange qualquer sequência alfanumérica, código QR, token ou credencial equivalente que, ao ser inserida em sistema de terceiro, desbloqueie funcionalidade de software ou serviço digital, independentemente da nomenclatura comercial adotada pelo desenvolvedor original.

**Nota 2.** A expressão "réplicas de armas, inclusive de airsoft", utilizada na Seção 3.3, é empregada em sentido amplo e abrange qualquer objeto que, pela aparência externa, possa ser confundido com arma real, ainda que desprovido de mecanismo funcional de disparo. A finalidade declarada pelo vendedor, seja ela recreativa, decorativa ou educacional, não afasta o enquadramento na categoria vedada.

**Nota 3.** A remissão à política POL COM 02 ao longo deste documento indica que o rito de análise, os prazos de manifestação e os critérios de gradação de sanções estão integralmente disciplinados naquele instrumento, não cabendo ao presente documento reproduzi-los ou modificá-los. Em caso de atualização da política POL COM 02, as remissões aqui contidas passam automaticamente a se referir à versão vigente.

**Nota 4.** A remissão à política POL CAD 01 no Preâmbulo indica que as condições de elegibilidade para cadastro e as hipóteses de encerramento compulsório de conta estão disciplinadas naquele instrumento, sendo a suspensão definitiva prevista na Seção 5.3 desta política uma das causas de encerramento ali contempladas.

---

## Anexo. Quadro Resumo das Categorias Vedadas

| Categoria | Exemplos Representativos | Seção de Referência |
|---|---|---|
| Programas de Computador | Licenças, chaves de ativação, contas de acesso, assinaturas revendidas | 3.1 |
| Saúde | Medicamentos, suplementos sem registro, produtos com exigência de receita | 3.2 |
| Segurança | Armas, réplicas de armas inclusive de airsoft, explosivos, itens de uso policial restrito | 3.3 |
| Animais e Derivados | Animais vivos, ovos férteis silvestres, partes de animais protegidos | 3.4 |
| Documentos e Dados | Documentos oficiais, diplomas, dados pessoais, cadastros de terceiros | 3.5 |
| Cosméticos | Cosméticos sem registro sanitário, produtos sem procedência comprovada | 3.6 |

O presente quadro tem caráter meramente informativo e não substitui a leitura integral das subseções correspondentes. Em caso de divergência entre o quadro e o texto das subseções, prevalece o texto das subseções.
