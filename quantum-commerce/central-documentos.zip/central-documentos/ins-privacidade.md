# Política de Privacidade

**Versão 1.0**
**Data de vigência. conforme publicação no portal da plataforma**

---

## 1. Objetivo e Âmbito

Esta política descreve como a plataforma coleta, utiliza, armazena e trata os dados pessoais dos clientes que utilizam seus serviços de marketplace. O objetivo central aqui estabelecido é garantir transparência plena sobre as práticas de tratamento de dados adotadas em todas as etapas da relação com o cliente, desde o primeiro acesso até o encerramento do vínculo contratual. A clareza sobre essas práticas não é apenas uma exigência regulatória, mas um compromisso assumido pela plataforma com todos aqueles que confiam seus dados ao ambiente por ela gerenciado.

Esta política se aplica a todos os clientes cadastrados, visitantes autenticados e parceiros que interagem com os serviços oferecidos pela plataforma, independentemente do canal de acesso utilizado. Isso significa que o escopo de aplicação abrange tanto os acessos realizados por interfaces web quanto aqueles realizados por aplicativos móveis, integrações de programação e quaisquer outros pontos de contato tecnológico disponibilizados pela plataforma ao longo do tempo.

O cumprimento das diretrizes aqui estabelecidas é obrigatório para todas as áreas internas da plataforma que realizem qualquer forma de tratamento de dados pessoais. Não há exceção funcional ou hierárquica que afaste essa obrigatoriedade. Toda equipe, processo ou sistema que opere sobre dados pessoais de clientes deve observar integralmente o conteúdo deste documento, sob pena de responsabilização interna conforme as normas disciplinares aplicáveis.

---

## 2. Definições

Os termos abaixo são utilizados ao longo deste documento com significados específicos e delimitados, e sua interpretação deve sempre considerar o contexto do ambiente de marketplace operado pela plataforma.

O termo **cliente** designa toda pessoa física ou jurídica que realiza cadastro e utiliza os serviços da plataforma. O termo **dados pessoais** abrange quaisquer informações relacionadas a uma pessoa identificada ou identificável, incluindo nome, endereço, e-mail e histórico de navegação. O termo **tratamento de dados** compreende qualquer operação realizada com dados pessoais, incluindo coleta, armazenamento, uso, compartilhamento e exclusão. O termo **canal de privacidade** refere-se ao meio oficial disponibilizado pela plataforma para que o cliente exerça seus direitos relacionados aos dados pessoais. Por fim, o termo **contrato de intermediação** designa o acordo firmado entre a plataforma e o cliente no momento do cadastro, que rege a prestação dos serviços de marketplace.

A correta compreensão dessas definições é indispensável para a interpretação uniforme das disposições contidas nas seções seguintes.

---

## 3. Finalidades do Tratamento de Dados

A plataforma trata os dados pessoais dos clientes exclusivamente para finalidades legítimas, determinadas e explícitas, em conformidade com a legislação de proteção de dados vigente. A principal finalidade é a execução do contrato de intermediação firmado no momento do cadastro, que constitui a base jurídica primária para o tratamento das informações fornecidas pelo cliente ao longo da relação contratual.

Além da execução contratual, os dados do cliente são tratados para processar pagamentos realizados dentro do ambiente da plataforma, garantindo a conclusão das transações comerciais de forma segura e rastreável. O tratamento também abrange atividades de prevenção a abusos, fraudes e comportamentos que violem os termos de uso da plataforma, o que inclui análises automatizadas e revisões manuais conduzidas pelas equipes responsáveis pela integridade do ambiente.

Nenhuma finalidade adicional será aplicada sem que o cliente seja previamente informado e, quando exigido pela legislação vigente, sem que o consentimento adequado seja obtido. A plataforma não utiliza os dados pessoais dos clientes para finalidades incompatíveis com as descritas nesta seção, e qualquer expansão de escopo dependerá de atualização formal desta política, com notificação aos clientes pelos canais oficiais.

---

## 4. Dados de Pagamento

Dados de pagamento não são armazenados pela plataforma em nenhuma hipótese.

O processamento de informações financeiras é realizado exclusivamente por parceiros especializados em meios de pagamento, que operam sob suas próprias políticas de segurança e conformidade, auditadas de acordo com os padrões internacionais aplicáveis ao setor. A plataforma não tem acesso aos dados completos de cartões de crédito, débito ou quaisquer outros instrumentos financeiros utilizados pelo cliente no momento da transação. A arquitetura técnica adotada foi deliberadamente concebida para que tais informações trafeguem e sejam processadas inteiramente fora dos sistemas internos da plataforma, sem qualquer possibilidade de retenção ou interceptação.

Em razão dessa estrutura, a plataforma não pode ser responsabilizada por incidentes relacionados ao armazenamento de dados de pagamento, uma vez que tais dados não são retidos em seus sistemas. Eventuais questionamentos sobre o tratamento de informações financeiras devem ser direcionados diretamente ao parceiro de meios de pagamento utilizado na transação específica, cujos dados de contato e políticas próprias estão disponíveis nos ambientes por eles gerenciados.

---

## 5. Direitos do Cliente

O cliente tem o direito de solicitar a exclusão de seus dados pessoais a qualquer momento, desde que não haja obrigação legal que exija a retenção dessas informações. Esse direito é exercido exclusivamente por meio do canal de privacidade disponibilizado pela plataforma, que constitui o único ponto oficial de recebimento e processamento dessas solicitações.

A plataforma responderá à solicitação de exclusão em até **15 dias** contados a partir do recebimento do pedido pelo canal de privacidade. O prazo de 15 dias se aplica igualmente a outras solicitações relacionadas ao exercício de direitos sobre dados pessoais, como pedidos de acesso, correção e portabilidade, garantindo uniformidade no tratamento de todas as demandas relacionadas à privacidade do cliente.

Caso a solicitação não possa ser atendida integralmente dentro do prazo de 15 dias, a plataforma comunicará o cliente sobre o motivo e indicará uma previsão para a conclusão do atendimento. Essa comunicação será realizada pelo mesmo canal pelo qual a solicitação foi recebida, salvo indicação expressa do cliente em sentido diverso. A plataforma se compromete a não deixar qualquer solicitação sem resposta dentro do prazo estabelecido, ainda que a resposta seja de caráter intermediário, informando o andamento do processo.

---

## 6. Exceções e Casos Especiais

A exclusão de dados poderá ser parcialmente restringida quando houver obrigação legal de retenção, como em casos de investigações regulatórias ou cumprimento de ordens judiciais. Nessas situações, a plataforma informará o cliente sobre a impossibilidade de exclusão integral, identificando, na medida do legalmente permitido, a natureza da restrição aplicável.

Dados utilizados de forma anonimizada, que não permitam a identificação do cliente, poderão ser mantidos pela plataforma para fins estatísticos e de melhoria dos serviços, uma vez que, nessa condição, deixam de constituir dados pessoais para os efeitos da legislação aplicável. Em situações de suspeita de fraude ou abuso, a plataforma poderá reter os dados necessários para conduzir investigações internas, mesmo após solicitação de exclusão, pelo tempo estritamente necessário à apuração dos fatos.

---

## 7. Disposições Gerais

Esta política poderá ser atualizada periodicamente pela plataforma, sendo o cliente notificado por meio dos canais oficiais de comunicação sempre que alterações relevantes forem introduzidas. A versão vigente desta política é sempre a mais recente publicada no portal da plataforma, e sua consulta regular é recomendada a todos os clientes e parceiros que mantenham vínculo ativo com os serviços oferecidos.

Dúvidas sobre esta política devem ser encaminhadas ao canal de privacidade da plataforma.

Esta política entra em vigor na data de sua publicação no portal da plataforma.

**Versão 1.0**
