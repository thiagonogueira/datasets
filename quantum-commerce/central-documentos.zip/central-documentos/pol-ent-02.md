# Política de Entregas e Prazos (POL ENT 02)

## Objetivo e Âmbito

Esta política estabelece as regras e os procedimentos aplicáveis a todas as entregas realizadas por meio da plataforma. O propósito central é garantir transparência nas relações entre compradores, vendedores e transportadoras, além de definir com clareza os direitos e as obrigações de cada parte envolvida no processo logístico. As disposições aqui contidas aplicam-se a todos os pedidos realizados na plataforma, sem exceção de categoria de produto, modalidade de frete contratada ou localização do destinatário. Não há pedido fora do escopo desta política.

Vendedores que operam na plataforma aceitam integralmente os termos aqui descritos no momento do cadastro. Essa aceitação não é simbólica. Ela vincula o vendedor a todas as consequências previstas em cada seção, incluindo retenção de repasse, acionamento para ressarcimento e demais medidas operacionais cabíveis.

---

## Definições

Os termos abaixo são utilizados ao longo deste documento com os significados descritos. A leitura desta seção é obrigatória antes de qualquer consulta às seções seguintes.

**Plataforma** refere-se ao ambiente digital de intermediação de compras e vendas que conecta compradores e vendedores.

**Prazo prometido** é o prazo de entrega exibido ao comprador no momento da visualização do anúncio, antes da finalização da compra.

**Dias úteis** são os dias de segunda a sexta-feira, excluídos feriados nacionais, estaduais e municipais reconhecidos oficialmente.

**Confirmação do pagamento** é o momento a partir do qual o prazo de entrega começa a ser contado, correspondendo à aprovação do pagamento pelo sistema financeiro da plataforma.

**Extravio** é a situação em que a encomenda não é localizada pela transportadora após investigação formal.

**Repasse ao vendedor** é a transferência dos valores devidos ao vendedor após a conclusão satisfatória da entrega.

**Transportadora** é a empresa contratada para realizar o transporte físico do produto do vendedor ao endereço do comprador.

---

## 1. Prazos de Referência

### 1.1 Exibição do prazo no anúncio

O prazo prometido aparece no anúncio antes da compra. Essa informação é de caráter vinculante e serve como referência para todas as avaliações de atraso descritas nesta política. O vendedor é responsável por manter o prazo informado compatível com sua capacidade real de despacho e com os prazos operacionais da transportadora por ele contratada. Anúncio publicado com prazo incorreto é responsabilidade exclusiva do vendedor, e a plataforma não absorve as consequências dessa inconsistência.

Na prática, isso significa que um vendedor que anuncia entrega em 5 dias úteis para uma capital e não consegue cumprir esse prazo por limitação interna da sua operação responde pelo atraso como se o prazo tivesse sido descumprido por qualquer outra razão. A origem do problema não altera a aplicação das regras desta política.

### 1.2 Prazos padrão por localidade

Os prazos de referência adotados pela plataforma são os seguintes.

| Localidade | Prazo de referência |
|---|---|
| Capitais e regiões metropolitanas | 5 dias úteis |
| Demais localidades | 10 dias úteis |

Esses prazos são contados da confirmação do pagamento. O prazo de 5 dias úteis aplica-se exclusivamente a capitais de estado e aos municípios oficialmente reconhecidos como integrantes de regiões metropolitanas. O prazo de 10 dias úteis aplica-se a todos os demais municípios do território nacional.

A contagem começa na confirmação do pagamento, não na data do pedido e não na data do despacho. Equipes de atendimento devem usar esse marco como referência única ao calcular se um prazo foi ou não descumprido.

Exceção. Pedido com envio internacional tem o prazo de referência contado em dobro, e o aviso aparece na página do produto.

### 1.3 Prazos diferenciados por anúncio

Quando o vendedor informa no anúncio um prazo diferente dos prazos de referência, o prazo informado no anúncio prevalece. A plataforma utiliza os prazos de referência apenas como parâmetro mínimo de qualidade e como base para abertura de investigações em caso de atraso.

---

## 2. Atraso na Entrega

### 2.1 Caracterização do atraso

O atraso é caracterizado quando a entrega não ocorre até o encerramento do prazo prometido. Passado esse prazo, o cliente aciona o atendimento da plataforma por meio dos canais oficiais disponíveis.

A plataforma não reconhece reclamações de atraso realizadas por canais não oficiais como base para abertura de investigação formal. Mensagens em redes sociais, contatos diretos com vendedores ou comunicações por canais externos ao sistema da plataforma não geram protocolo e não iniciam nenhum procedimento previsto nesta política. O cliente precisa registrar a ocorrência pelos canais oficiais para que qualquer ação seja tomada.

### 2.2 Investigação com a transportadora

Após o acionamento pelo cliente, a plataforma inicia contato formal com a transportadora responsável pelo envio. A investigação com a transportadora responde em até 7 dias úteis. Durante esse período, o cliente é informado sobre o andamento da apuração por meio de notificações no sistema da plataforma. Não há necessidade de o cliente entrar em contato repetidamente durante esse prazo, pois as atualizações são enviadas automaticamente conforme o caso avança.

### 2.3 Desfecho da investigação

Ao término da investigação, dois cenários são possíveis.

O primeiro ocorre quando a encomenda é localizada e a entrega pode ser concluída. Nesse caso, a transportadora retoma o processo de entrega e a plataforma monitora a conclusão até o recebimento pelo comprador.

O segundo ocorre quando o extravio é confirmado. Confirmado o extravio, o cliente escolhe entre reenvio e reembolso integral. A escolha é feita pelo cliente de forma expressa por meio do sistema da plataforma, e a plataforma executa a opção escolhida no menor prazo operacionalmente possível. Nenhuma das duas opções depende de concordância do vendedor para ser executada.

### 2.4 Responsabilidade do vendedor em caso de extravio

O vendedor é responsável pela contratação de uma transportadora confiável e pelo correto despacho do produto. Em casos de extravio confirmado, a plataforma pode realizar o reembolso ou o reenvio ao cliente e acionar o vendedor para ressarcimento, conforme os termos do contrato de uso da plataforma. A escolha de uma transportadora sem rastreamento adequado ou com histórico de problemas não isenta o vendedor dessa responsabilidade.

---

## 3. Entrega Constando como Realizada sem Recebimento

### 3.1 Abertura de verificação

Quando o sistema da transportadora registra a entrega como concluída, mas o cliente declara não ter recebido o produto, a plataforma adota procedimento específico. O atendimento solicita a confirmação de endereço e abre verificação com a transportadora, com retenção do repasse ao vendedor até a conclusão. Essa retenção protege o comprador enquanto os fatos são apurados e não representa penalidade ao vendedor, apenas cautela operacional.

Exemplo de situação comum. o rastreamento indica entrega realizada em determinado dia, mas o cliente informa que não estava no endereço e nenhum vizinho ou porteiro recebeu o produto em seu nome. Esse tipo de ocorrência abre verificação imediatamente.

### 3.2 Prazo da verificação

A verificação segue os mesmos prazos da investigação por atraso descrita na seção 2. A transportadora tem até 7 dias úteis para apresentar comprovação da entrega, incluindo assinatura, foto ou outro registro aceito pela plataforma.

### 3.3 Resultado da verificação

Se a transportadora comprovar a entrega de forma satisfatória, o repasse ao vendedor é liberado e o caso é encerrado. Se a transportadora não conseguir comprovar a entrega, a plataforma trata o caso como extravio e aplica as regras previstas na seção 2.3.

---

## 4. Frete em Caso de Atraso

### 4.1 Direito ao reembolso do frete

Quando o atraso da entrega é confirmado, o frete é reembolsado ao cliente, independentemente do desfecho do pedido. Esse direito existe tanto nos casos em que o cliente opta pelo reenvio quanto nos casos em que o cliente opta pelo reembolso integral do produto. Não há situação de atraso confirmado em que o cliente perca o direito ao valor do frete.

### 4.2 Forma e momento do reembolso

O cliente recebe o frete de volta junto com a resolução do pedido. O frete é reembolsado por meio do mesmo método de pagamento utilizado na compra original, salvo impossibilidade técnica, caso em que a plataforma oferece alternativa equivalente. O prazo para o crédito aparecer depende do método de pagamento original e das regras da instituição financeira envolvida, mas a plataforma executa o processo no menor tempo operacionalmente possível após a resolução do caso.

### 4.3 Frete em casos de entrega não reconhecida

Nos casos descritos na seção 3, o frete é reembolsado apenas se a verificação concluir que a entrega não foi realizada. Se a entrega for comprovada, o valor do frete não é devolvido. Essa distinção é importante. o frete de volta ao cliente está condicionado à confirmação de falha na entrega, não à simples declaração do cliente de que não recebeu o produto.

---

## 5. Exceções e Casos Especiais

### 5.1 Eventos extraordinários

Situações de força maior, como desastres naturais, greves generalizadas ou bloqueios de vias, podem impactar os prazos de entrega. Nesses casos, a plataforma comunica os compradores afetados e avalia cada situação individualmente antes de aplicar as penalidades previstas nesta política. A comunicação é feita de forma proativa, sem necessidade de o cliente abrir chamado para ser informado.

### 5.2 Endereço incorreto informado pelo comprador

Quando o atraso ou o não recebimento decorre de endereço incorreto informado pelo comprador no momento da compra, a plataforma não aplica as regras de reembolso de frete descritas na seção 4. O comprador assume a responsabilidade pelos custos adicionais de reenvio ou devolução nesse cenário.

Exemplo de situação. o comprador digita o número do apartamento errado e a encomenda é entregue a outro morador do mesmo prédio. Se o erro de endereço for comprovado pelo registro da transportadora, o caso não segue as regras de atraso ou extravio desta política.

### 5.3 Produtos com restrição logística

Produtos que exigem condições especiais de transporte podem ter prazos diferenciados informados no anúncio. Esses prazos prevalecem sobre os prazos de referência da seção 1.2 e são tratados como prazo prometido para fins desta política.

---

## 6. Disposições Gerais

### 6.1 Vigência

Esta política entra em vigor na data de sua publicação e permanece válida até que uma versão revisada seja publicada pela plataforma.

### 6.2 Versão

Versão 1.0. Documento identificado como POL ENT 02.

### 6.3 Revisões

A plataforma reserva-se o direito de revisar esta política a qualquer momento. Alterações relevantes serão comunicadas a vendedores e compradores com antecedência mínima de 15 dias antes de sua entrada em vigor.

### 6.4 Prevalência

Em caso de conflito entre esta política e qualquer comunicação informal realizada por canais de atendimento, prevalece o disposto neste documento. Esta política é parte integrante dos termos de uso da plataforma e complementa as demais políticas vigentes. Respostas de agentes de atendimento que contradigam o que está escrito aqui não têm validade para fins de concessão de benefícios ou isenção de penalidades.

### 6.5 Foro

Fica eleito o foro da comarca da sede da plataforma para dirimir quaisquer controvérsias decorrentes da aplicação desta política, com renúncia expressa a qualquer outro, por mais privilegiado que seja.

---

## Perguntas Frequentes

**O prazo começa a contar a partir de quando?**
A contagem começa na confirmação do pagamento pelo sistema financeiro da plataforma. A data do pedido e a data do despacho não são usadas como marco inicial.

**O que acontece se o vendedor anunciou um prazo menor que o prazo de referência da plataforma?**
O prazo anunciado prevalece. Se o vendedor anunciou entrega em 5 dias úteis para uma localidade onde o prazo de referência seria 10 dias úteis, a plataforma usa os 5 dias úteis como base para avaliar atraso.

**O cliente precisa fazer algo durante os 7 dias úteis de investigação?**
Não. Após o acionamento pelo canal oficial, o cliente recebe atualizações automáticas pelo sistema da plataforma. Não é necessário entrar em contato repetidamente durante esse período.

**O frete é reembolsado mesmo que o cliente escolha o reenvio do produto?**
Sim. O frete é reembolsado independentemente do desfecho escolhido pelo cliente. Tanto no reenvio quanto no reembolso integral do produto, o valor do frete retorna ao cliente quando o atraso é confirmado.

**E se a transportadora registrar a entrega como feita, mas o cliente não tiver recebido nada?**
A plataforma abre verificação com a transportadora, que tem até 7 dias úteis para apresentar comprovação, como assinatura ou foto. O repasse ao vendedor fica retido durante esse período. Se a entrega não for comprovada, o caso é tratado como extravio.

**O frete de volta é garantido em todos os casos de não recebimento?**
Não. O frete de volta ao cliente é garantido quando o atraso ou o extravio é confirmado. Se a entrega for comprovada pela transportadora ou se o problema decorreu de endereço incorreto informado pelo comprador, o valor do frete não é devolvido.

**O que acontece com o vendedor quando um extravio é confirmado?**
A plataforma executa o reembolso ou o reenvio ao cliente e pode acionar o vendedor para ressarcimento conforme o contrato de uso. A resolução para o cliente não depende dessa etapa com o vendedor.

**Feriados afetam a contagem de dias úteis?**
Sim. Dias úteis são os dias de segunda a sexta-feira, excluídos feriados nacionais, estaduais e municipais reconhecidos oficialmente. Feriados não entram na contagem.

**O que vale em caso de conflito entre o que um agente de atendimento disse e o que está nesta política?**
Prevalece o disposto nesta política (POL ENT 02). Comunicações informais de canais de atendimento não substituem nem alteram as regras aqui descritas.

**Com quanto tempo de antecedência a plataforma avisa sobre mudanças nesta política?**
Alterações relevantes são comunicadas com antecedência mínima de 15 dias antes de entrarem em vigor.
