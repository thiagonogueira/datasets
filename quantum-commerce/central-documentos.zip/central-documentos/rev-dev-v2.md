# Política de Trocas, Devoluções e Ressarcimento (POL DEV 03, versão 2)

Versão 2, vigente de 01/01/2026 a 30/06/2026. Substituída pela versão 3.

Vigente a partir de 01/07/2026. Substitui a versão 2.

---

## Objetivo e Âmbito

Esta política estabelece as regras aplicáveis a todos os pedidos de troca, devolução e ressarcimento realizados por meio da plataforma. O documento é válido para compras efetuadas por pessoas físicas e jurídicas cadastradas como compradores ativos, independentemente da categoria de produto adquirida, do valor da compra ou da modalidade de pagamento utilizada. As regras aqui descritas se aplicam a todas as categorias de produtos disponíveis na plataforma, salvo disposição expressa em contrário indicada em política específica de categoria.

A plataforma atua como intermediadora entre comprador e vendedor e garante o cumprimento destas regras por parte dos vendedores cadastrados em seu ambiente. Isso significa que, em qualquer situação de conflito entre o que está escrito neste documento e qualquer comunicação informal de vendedor, prevalece o disposto nesta política. Mensagens enviadas diretamente pelo vendedor ao comprador fora dos canais oficiais da plataforma não têm validade para fins de alteração de prazos, condições de devolução ou valores de ressarcimento.

Esta versão substitui integralmente a versão 2 da POL DEV 03 para todos os pedidos realizados a partir de 01/07/2026.

---

## Definições

Para fins de interpretação e aplicação desta política, os termos abaixo têm os seguintes significados.

**Comprador** é a pessoa física ou jurídica que realiza a compra por meio da plataforma.

**Vendedor** é a pessoa física ou jurídica que oferta produtos na plataforma e que é responsável pela qualidade e conformidade do item anunciado.

**Chamado** é o registro formal aberto pelo comprador na central de atendimento da plataforma para solicitar troca, devolução ou ressarcimento.

**Divergência** é qualquer diferença verificável entre o produto recebido e o produto descrito no anúncio, incluindo cor, modelo, tamanho, quantidade e especificações técnicas.

**Defeito** é qualquer falha de fabricação, funcionamento ou integridade física do produto que comprometa seu uso normal.

**Plano padrão** é a modalidade de cadastro básica, sem assinatura de programa de fidelidade.

**Clube Q+** é o programa de assinatura da plataforma, cujas condições específicas estão descritas na política POL CLU 01.

**POL GAR 01** é a política de garantia por categoria de produto, que define os prazos aplicáveis a cada tipo de item comercializado na plataforma.

---

## Seção 1. Direito de Arrependimento

### 1.1 Prazo e condições gerais

O comprador pode desistir de qualquer compra realizada na plataforma em até sete dias corridos contados da data de recebimento do produto. O exercício desse direito não exige justificativa e não gera nenhum ônus ao comprador. O reembolso decorrente do arrependimento é integral e inclui o valor do frete pago no momento da compra.

### 1.2 Como exercer o direito de arrependimento

Para exercer o direito de arrependimento, o comprador deve abrir um chamado na central de atendimento da plataforma dentro do prazo de sete dias corridos mencionado na cláusula 1.1. O chamado deve indicar o número do pedido e a opção de desistência. Após a abertura do chamado, a plataforma fornece as instruções para devolução do produto ao vendedor, sem custo para o comprador. O comprador não precisa contatar o vendedor diretamente para iniciar esse processo.

Situação comum. um comprador recebe um par de tênis na segunda-feira, experimenta e decide que não quer manter a compra. Ele abre o chamado na quinta-feira do mesmo período, dentro do prazo. A plataforma gera a etiqueta de devolução e o comprador entrega o produto nos pontos de coleta indicados, sem custo para o comprador, e o reembolso é processado conforme a faixa de valor da compra descrita na Seção 3.

### 1.3 Estado do produto devolvido

O produto deve ser devolvido em condições que permitam sua identificação como o item original do pedido. A plataforma pode recusar o ressarcimento caso o produto seja devolvido com danos causados por uso inadequado que não sejam pré-existentes ao recebimento. Danos de transporte ocorridos durante a devolução são de responsabilidade da plataforma quando a logística reversa for providenciada por ela.

### 1.4 Reafirmação do prazo

O prazo de sete dias corridos é contado a partir do dia seguinte ao recebimento confirmado do produto. A confirmação de recebimento pode ser feita pelo registro de entrega da transportadora ou por declaração do comprador na plataforma. Pedidos com mais de um item têm o prazo contado a partir do recebimento do último item do pedido, quando enviados juntos.

### 1.5 Produtos não elegíveis

Produtos personalizados, produzidos sob encomenda ou que por sua natureza não possam ser devolvidos (como itens perecíveis ou de higiene pessoal já abertos) não são elegíveis ao direito de arrependimento previsto nesta seção. A inelegibilidade de cada categoria está indicada na página do produto e na política POL GAR 01. O comprador deve verificar essa informação antes de finalizar a compra.

---

## Seção 2. Devolução por Divergência ou Defeito

### 2.1 Direito à troca ou ao reembolso

Quando o produto recebido apresentar divergência em relação ao anúncio ou defeito comprovado, o comprador escolhe entre troca e reembolso integral. A escolha é feita no momento da abertura do chamado e pode ser alterada apenas uma vez, desde que a solicitação de alteração ocorra antes do início do processamento da solicitação original.

### 2.2 Opção de troca

O comprador que escolhe entre troca e reembolso e opta pela troca deve indicar essa preferência diretamente no chamado aberto na plataforma. A troca será pelo mesmo produto, na mesma especificação, salvo indisponibilidade de estoque. Em caso de indisponibilidade, a plataforma oferece ao comprador a opção de aguardar a reposição ou receber o reembolso integral. Nenhuma das duas alternativas gera custo adicional ao comprador.

Situação comum. um comprador recebe um carregador portátil com capacidade diferente da descrita no anúncio. Ele abre o chamado indicando preferência por troca. O vendedor não tem mais unidades disponíveis. A plataforma comunica a indisponibilidade e oferece as duas alternativas. O comprador escolhe o reembolso integral e o processo segue conforme a Seção 3.

### 2.3 Prazos para solicitação

O prazo para solicitar devolução por divergência ou defeito segue a tabela de garantia por categoria descrita na política POL GAR 01. O prazo é contado a partir da data de recebimento do produto. O comprador deve verificar a categoria do produto adquirido para identificar o prazo aplicável ao seu caso.

### 2.4 Análise da solicitação

Após a abertura do chamado, a plataforma realiza a análise da solicitação com base nas informações e evidências fornecidas pelo comprador. O comprador pode ser solicitado a enviar fotografias ou vídeos do produto para subsidiar a análise. A decisão da plataforma será comunicada ao comprador pelo canal de atendimento registrado no chamado.

Para agilizar a análise, o comprador deve incluir no chamado. - Número do pedido
- Descrição objetiva da divergência ou do defeito identificado
- Fotografias ou vídeos do produto, preferencialmente comparando com a descrição do anúncio
- Registro de entrega da transportadora, quando disponível

---

## Seção 3. Ressarcimento por Faixa de Valor

### 3.1 Tabela de tratamento por faixa

O valor total pago pelo comprador na compra define o fluxo de processamento do ressarcimento, conforme a tabela abaixo.

| Faixa de valor da compra | Tratamento |
|---|---|
| Até R$ 100,00 | Reembolso integral, em 7 dias úteis |
| De R$ 100,01 a R$ 500,00 | Reembolso integral após análise, em 15 dias úteis |
| Acima de R$ 500,00 | Análise documental, teto de R$ 2.000,00 |

### 3.2 Teto de ressarcimento para o plano padrão

O teto de R$ 2.000,00 por compra aplica-se exclusivamente a compradores cadastrados no plano padrão. Esse valor foi fixado nesta versão da política. Compras cujo valor total supere R$ 2.000,00 terão o ressarcimento limitado a esse teto para clientes do plano padrão, sendo o valor excedente objeto de análise complementar conduzida pela equipe de atendimento.

### 3.3 Teto para assinantes do Clube Q+

Assinantes do Clube Q+ têm teto de ressarcimento próprio, definido nos termos do programa descritos na política POL CLU 01. O teto do Clube Q+ não é regulado por esta política e pode ser superior ao teto do plano padrão. Em caso de dúvida sobre o teto aplicável, o comprador deve consultar sua modalidade de cadastro na área de conta da plataforma.

### 3.4 Documentação exigida para compras acima de R$ 500,00

Para compras acima de R$ 500,00, a análise documental pode incluir a apresentação dos seguintes documentos. - Nota fiscal do produto
- Comprovante de recebimento
- Registro fotográfico do produto, mostrando o defeito ou a divergência identificada

A plataforma comunicará ao comprador quais documentos são necessários em cada caso, pois a exigência pode variar conforme a categoria do produto e a natureza da solicitação. O prazo de processamento do ressarcimento começa a contar a partir da data de entrega completa da documentação solicitada. Documentação incompleta suspende o prazo até que todos os itens sejam entregues.

---

## Seção 4. Meio de Pagamento do Ressarcimento

### 4.1 Regra geral de devolução do valor

O ressarcimento aprovado pela plataforma retorna ao comprador pelo mesmo meio de pagamento usado na compra original. Essa regra aplica-se a todas as modalidades de pagamento aceitas pela plataforma e não admite exceções, salvo o caso previsto na cláusula 4.3.

### 4.2 Exemplos de aplicação da regra

A compra realizada com cartão de crédito ou débito gera estorno no próprio cartão utilizado na transação. A compra realizada por pix gera devolução na conta de origem do pagamento, identificada pela chave pix utilizada. O prazo para que o valor apareça na conta ou no extrato do comprador depende da instituição financeira e pode variar conforme as regras de cada operadora. A plataforma não tem controle sobre os prazos internos de cada instituição financeira após o processamento do ressarcimento em seu sistema.

Situação comum. um comprador realizou uma compra parcelada em cartão de crédito e teve o ressarcimento aprovado. O estorno será lançado no mesmo cartão, podendo aparecer como crédito na fatura atual ou na seguinte, conforme as regras da operadora do cartão. A plataforma processa o ressarcimento pelo mesmo meio de pagamento e envia a confirmação ao comprador pelo canal de atendimento.

### 4.3 Cupom da plataforma como alternativa

O ressarcimento em forma de cupom da plataforma somente é válido quando houver aceite expresso do comprador durante o processo de atendimento. O aceite expresso deve ser registrado no chamado e não pode ser presumido por omissão ou silêncio do comprador. Caso o comprador não manifeste o aceite expresso, o ressarcimento seguirá obrigatoriamente pelo mesmo meio de pagamento usado na compra.

### 4.4 Reafirmação da regra do meio de pagamento

A plataforma não realiza ressarcimentos por meios diferentes do mesmo meio de pagamento usado na compra, exceto na hipótese de aceite expresso descrita na cláusula 4.3. Essa regra protege o comprador de redirecionamentos não solicitados de valores e garante a rastreabilidade das transações.

---

## Seção 5. Recusa no Ato da Entrega

### 5.1 Direito de recusa na entrega

O comprador tem o direito de recusar o recebimento do produto no momento da entrega, por qualquer motivo.

### 5.2 Consequências da recusa

O produto recusado no ato da entrega retorna diretamente ao vendedor por meio da transportadora responsável. Após a confirmação do retorno do produto, a cobrança é cancelada integralmente, incluindo parcelas futuras no caso de compras parceladas. O comprador não precisa abrir chamado adicional para solicitar o cancelamento da cobrança quando a recusa ocorrer no ato da entrega.

Situação comum. um comprador recebe a visita da transportadora e percebe que a embalagem está completamente amassada e com sinais evidentes de avaria. Ele recusa o recebimento diretamente ao entregador. O produto retorna ao vendedor e a cobrança é cancelada após a confirmação do retorno, sem necessidade de abertura de chamado pelo comprador.

### 5.3 Registro da recusa

A recusa deve ser registrada junto ao entregador no momento da tentativa de entrega. A plataforma recomenda que o comprador fotografe o produto e a embalagem antes de recusá-lo, para fins de registro. O comprador pode informar a recusa também pelo canal de atendimento da plataforma, para acompanhamento do retorno do produto ao vendedor. Esse registro adicional não substitui a recusa formal junto ao entregador, mas contribui para o acompanhamento do processo.

### 5.4 Reafirmação do cancelamento da cobrança

A cobrança é cancelada após a confirmação do retorno do produto ao vendedor. O prazo para o cancelamento aparecer no extrato do comprador depende da modalidade de pagamento utilizada e das regras da instituição financeira. A plataforma acompanha o processo e notifica o comprador quando o cancelamento for processado.

---

## Seção 6. Exceções e Casos Especiais

### 6.1 Divergência entre políticas

Em caso de divergência entre esta política e qualquer versão anterior da POL DEV 03, prevalece sempre a versão mais recente. Esta versão 2 substitui integralmente a versão 2 para todos os pedidos realizados a partir de 01/07/2026. Pedidos realizados antes dessa data seguem as regras da versão vigente no momento da compra.

### 6.2 Situações não previstas

Situações não previstas expressamente nesta política serão analisadas pela equipe de atendimento da plataforma com base nos princípios gerais de boa-fé, razoabilidade e proteção ao consumidor. A decisão da plataforma em casos omissos será comunicada ao comprador com justificativa.

---

## Seção 7. Disposições Gerais

### 7.1 Vigência e versão

Esta política entra em vigor em 01/07/2026 e substitui a versão 2 da POL DEV 03. A versão vigente sempre estará disponível na central de ajuda da plataforma.

### 7.2 Referências normativas

Esta política deve ser lida em conjunto com a POL GAR 01 (garantia por categoria) e a POL CLU 01 (termos do Clube Q+). A leitura isolada desta política, sem consulta às referências normativas indicadas, pode gerar interpretações incompletas sobre prazos e tetos aplicáveis a cada situação.

### 7.3 Atualizações

A plataforma pode atualizar esta política a qualquer momento, com comunicação prévia aos compradores cadastrados. Alterações que impliquem redução de direitos somente entram em vigor após o prazo mínimo de comunicação previsto na legislação aplicável.

### 7.4 Foro e legislação aplicável

Esta política é regida pela legislação brasileira vigente. Fica eleito o foro da comarca do domicílio do comprador para resolução de eventuais conflitos não solucionados pelos canais de atendimento da plataforma.

---

## Perguntas Frequentes

**Posso desistir da compra sem dar nenhuma explicação?**

Sim. O direito de arrependimento não exige justificativa. O comprador precisa apenas abrir o chamado dentro do prazo de sete dias corridos contados do recebimento do produto.

**O frete de devolução é cobrado de mim?**

Não. Quando a devolução decorre do exercício do direito de arrependimento ou de divergência ou defeito comprovado, a logística reversa é providenciada pela plataforma sem custo para o comprador.

**Posso receber o ressarcimento em outra conta diferente da que usei para pagar?**

Não, salvo uma exceção. O ressarcimento retorna pelo mesmo meio de pagamento usado na compra original. A única alternativa é o cupom da plataforma, que só é válido com aceite expresso do comprador registrado no chamado.

**O que acontece se eu recusar o produto na entrega?**

O produto retorna ao vendedor pela transportadora e a cobrança é cancelada após a confirmação do retorno. Compras parceladas têm todas as parcelas futuras canceladas. O comprador não precisa abrir chamado adicional nessa situação.

**Minha compra foi acima de R$ 2.000,00. Vou receber tudo de volta?**

Depende da sua modalidade de cadastro. Para compradores do plano padrão, o teto de ressarcimento é de R$ 2.000,00 por compra, conforme esta versão da política. O valor excedente passa por análise complementar. Assinantes do Clube Q+ têm teto próprio definido na política POL CLU 01 e devem consultar esse documento para verificar o valor aplicável.

**Posso trocar o produto por um modelo diferente do que comprei?**

Não. A troca é realizada pelo mesmo produto, na mesma especificação. Se o produto não estiver disponível em estoque, a plataforma oferece a opção de aguardar a reposição ou receber o reembolso integral.

**Quanto tempo tenho para pedir a devolução por defeito?**

O prazo varia conforme a categoria do produto adquirido e está descrito na política POL GAR 01. O comprador deve consultar essa política para identificar o prazo aplicável ao seu caso.

**Posso alterar minha escolha entre troca e reembolso depois de abrir o chamado?**

Sim, mas apenas uma vez. A alteração precisa ser solicitada antes do início do processamento da solicitação original. Após o início do processamento, a escolha não pode mais ser modificada.

**O vendedor me disse que a política dele é diferente. Qual prevalece?**

Sempre prevalece o disposto nesta política. Comunicações informais de vendedores fora dos canais oficiais da plataforma não têm validade para alterar prazos, condições ou valores de ressarcimento.

**Onde encontro a versão atualizada desta política?**

A versão vigente da POL DEV 03 está sempre disponível na central de ajuda da plataforma. Em caso de atualização, os compradores cadastrados recebem comunicação prévia.

---

Documento. POL DEV 03, versão 2.
Data de vigência. 01/07/2026.
Substitui. POL DEV 03, versão 2.
Referências. POL GAR 01, POL CLU 01.
