# Termos do programa Clube Q+ (POL CLU 01)

Versão inicial, vigente até 31/12/2025. Substituída pelos termos vigentes.

## Objetivo e Âmbito

Este documento estabelece, de forma exaustiva e vinculante, as regras, condições, limitações e benefícios associados ao programa de assinatura denominado Clube Q+, operado exclusivamente pela plataforma. A presente política aplica-se, sem exceção, a todos os usuários que contratarem o plano de assinatura ativo e vigente, bem como às equipes internas responsáveis pelo atendimento ao consumidor, logística de entrega, processamento de reembolsos e quaisquer outras funções operacionais que interajam direta ou indiretamente com os assinantes do programa. A abrangência desta política compreende ainda as relações entre a plataforma e vendedores terceiros cadastrados, na medida em que tais relações afetem a fruição dos benefícios descritos neste instrumento.

Em caso de conflito entre o disposto neste documento e qualquer comunicação informal, mensagem eletrônica, notificação automática ou declaração verbal de representante da plataforma, prevalece integralmente o disposto nesta política, sendo as demais comunicações consideradas meramente informativas e sem força normativa. A plataforma reserva-se o direito de atualizar os termos aqui descritos, desde que comunique os assinantes com antecedência mínima conforme previsto na seção de Disposições Gerais deste mesmo instrumento, bem como nos termos de uso gerais da plataforma, incorporados a este documento por remissão expressa.

---

## Definições

Para fins de interpretação e aplicação desta política, os termos abaixo possuem os seguintes significados, os quais prevalecem sobre acepções comuns ou técnicas diversas que possam ser atribuídas às mesmas expressões em outros contextos.

**Assinante** é o usuário, pessoa física ou jurídica, que contratou e mantém ativa a assinatura do Clube Q+, estando em dia com todas as obrigações decorrentes do plano contratado.

**Produto elegível** é qualquer item comercializado na plataforma que esteja devidamente sinalizado como apto a receber os benefícios do programa, conforme critérios definidos e periodicamente revisados pela equipe de operações, sem necessidade de comunicação prévia individualizada aos assinantes.

**Chamado** é qualquer solicitação formal registrada pelo assinante nos canais oficiais de atendimento da plataforma, sendo desconsideradas para fins desta política as manifestações realizadas por canais não oficiais, redes sociais ou aplicativos de mensagens instantâneas.

**POL DEV 03** é o documento interno que regulamenta os procedimentos gerais de devolução e reembolso aplicáveis a todos os usuários da plataforma, assinantes ou não, e ao qual esta política faz remissão expressa em diversas de suas disposições.

**Fila prioritária** é o sistema de triagem de chamados que posiciona as solicitações de assinantes à frente das demais, garantindo tempo de resposta diferenciado conforme os parâmetros estabelecidos na Seção 3 deste documento.

> **Nota explicativa.** As definições acima são taxativas para os fins desta política. Termos não definidos nesta seção devem ser interpretados à luz do glossário geral da plataforma, disponível na central de documentos, e, subsidiariamente, conforme a legislação brasileira aplicável.

---

## 1. O Programa

### 1.1 Descrição Geral

O Clube Q+ é o programa de assinatura da plataforma, concebido para reconhecer e recompensar o engajamento contínuo de usuários frequentes por meio de um conjunto estruturado de benefícios exclusivos. O programa opera em caráter permanente, podendo ser suspenso ou encerrado mediante comunicação prévia aos assinantes nos termos previstos na seção de Disposições Gerais.

### 1.2 Benefícios Incluídos

A assinatura ativa do Clube Q+ garante ao assinante o acesso aos seguintes benefícios, os quais são aplicáveis exclusivamente durante o período de vigência da assinatura e não geram direitos adquiridos após o cancelamento ou a suspensão do plano.

O primeiro benefício é o frete grátis em produtos elegíveis, aplicado automaticamente no momento da finalização da compra, sem necessidade de inserção de cupom, código promocional ou qualquer ação adicional por parte do assinante. A aplicação automática está condicionada à identificação do status ativo da assinatura pelo sistema da plataforma no momento exato da conclusão do pedido.

O segundo benefício é o atendimento prioritário, por meio do qual os chamados do assinante são encaminhados à fila prioritária, conforme descrito em detalhes na Seção 3 desta política.

O terceiro benefício são as condições próprias de reembolso, que diferem das condições aplicáveis aos demais usuários da plataforma, conforme descrito em detalhes na Seção 2 desta política e em conformidade com a POL DEV 03.

### 1.3 Elegibilidade ao Frete Grátis

O benefício de frete grátis se aplica exclusivamente a produtos sinalizados como elegíveis na página de listagem da plataforma, sendo de responsabilidade do assinante verificar a sinalização antes de concluir a compra. Produtos de vendedores terceiros podem estar sujeitos a restrições adicionais definidas pelo próprio vendedor, desde que tais restrições estejam claramente indicadas na página do produto no momento da visualização pelo assinante. A plataforma não garante a aplicação do frete grátis em categorias excluídas do programa, incluindo, sem limitação, itens de grande porte com logística especial e produtos de regiões com cobertura restrita. A lista de categorias excluídas é mantida atualizada na central de ajuda da plataforma, sendo de responsabilidade do assinante consultá-la previamente à realização de compras. A plataforma não se responsabiliza por expectativas geradas por informações desatualizadas obtidas em fontes não oficiais.

> **Nota explicativa.** A elegibilidade ao frete grátis é verificada no momento da finalização do pedido. Alterações no status de elegibilidade de um produto após a conclusão da compra não afetam o pedido já realizado, mas passam a valer para compras subsequentes sem necessidade de aviso individualizado.

---

## 2. Reembolso do Assinante

### 2.1 Teto de Reembolso

Para assinantes do Clube Q+, o teto de reembolso por compra é de R$ 5.000,00. Esse limite se aplica por transação individual e não é cumulativo entre compras distintas realizadas no mesmo período de faturamento ou em períodos distintos. Compras cujo valor total supere R$ 5.000,00 terão o reembolso limitado a R$ 5.000,00, cabendo ao assinante verificar condições complementares junto ao canal de atendimento oficial da plataforma antes de formalizar a solicitação.

### 2.2 Prazos de Reembolso

Os prazos de reembolso aplicáveis aos assinantes do Clube Q+ correspondem à os mesmos prazos estabelecidos na política geral da plataforma para usuários não assinantes. Essa redução é aplicada automaticamente pelo sistema ao identificar-se que o solicitante possui assinatura ativa no momento do registro da solicitação, sem necessidade de requerimento expresso pelo assinante. Assinantes que cancelarem a assinatura após o início de um processo de reembolso terão seus prazos recalculados conforme as regras da política geral, sem direito a retroatividade do benefício ou a qualquer forma de compensação pela perda da condição diferenciada.

### 2.3 Procedimento de Reembolso

As faixas de valor e o procedimento completo de reembolso seguem o disposto na POL DEV 03. O presente documento não substitui nem revoga a POL DEV 03, operando em caráter complementar e estabelecendo exclusivamente as condições especiais aplicáveis aos assinantes do Clube Q+. Em caso de dúvida sobre o procedimento aplicável, o assinante deve consultar a POL DEV 03 diretamente na central de documentos da plataforma, sendo vedada a interpretação isolada das disposições desta seção sem a leitura conjunta daquele instrumento.

### 2.4 Casos Especiais de Reembolso

Situações envolvendo fraude comprovada, uso indevido da assinatura, cessão não autorizada dos benefícios a terceiros ou solicitações registradas fora do prazo regulamentar estão sujeitas a análise individual pela equipe de operações, com suspensão temporária dos benefícios diferenciados durante o período de apuração. Nesses casos, o teto de R$ 5.000,00 pode ser suspenso temporariamente até a conclusão da investigação, sem que tal suspensão configure violação dos direitos do assinante. A plataforma comunicará o assinante sobre o andamento do caso dentro do prazo de primeira resposta estabelecido na Seção 3, assegurado o contraditório nos termos da POL DEV 03.

---

## 3. Atendimento Prioritário

### 3.1 Fila Prioritária

Chamados registrados por assinantes ativos do Clube Q+ entram automaticamente em fila prioritária no sistema de atendimento da plataforma, sem necessidade de solicitação expressa. Essa classificação é feita de forma automática mediante verificação do status da assinatura no momento do registro do chamado, sendo desconsiderada qualquer alteração de status ocorrida após o registro para fins de determinação do tratamento aplicável àquele chamado específico.

### 3.2 Prazo de Primeira Resposta

A primeira resposta a chamados de assinantes ocorre em até 2 dias úteis a partir do registro formal da solicitação nos canais oficiais da plataforma. Esse prazo se refere à primeira resposta humana e não garante a resolução completa do chamado dentro do mesmo período, podendo a conclusão do atendimento estender-se conforme a complexidade da solicitação e os procedimentos previstos na POL DEV 03. Chamados registrados fora do horário comercial terão a contagem do prazo iniciada no próximo dia útil subsequente ao registro.

### 3.3 Exceções ao Atendimento Prioritário

Em situações de volume extraordinário de chamados, como eventos promocionais de alta demanda, falhas sistêmicas generalizadas ou circunstâncias de força maior devidamente reconhecidas pela plataforma, o prazo de 2 dias úteis pode ser estendido de forma temporária e proporcional à situação que o motivou. A plataforma comunicará publicamente qualquer alteração temporária nos prazos de atendimento por meio de aviso na página inicial e nos canais oficiais de comunicação, não sendo devida qualquer compensação ao assinante em razão de tais extensões excepcionais.

---

## 4. Tabela de Benefícios Consolidados

A tabela abaixo consolida os benefícios do Clube Q+ para referência rápida do assinante e das equipes internas, sem prejuízo da leitura integral das seções correspondentes.

| Benefício | Condição de Aplicação | Seção de Referência |
|---|---|---|
| frete grátis | Produto elegível e assinatura ativa | Seção 1.3 |
| Teto de reembolso de R$ 5.000,00 | Assinatura ativa no momento da solicitação | Seção 2.1 |
| Prazo de reembolso reduzido | Assinatura ativa no momento do registro | Seção 2.2 |
| Fila prioritária | Assinatura ativa no momento do chamado | Seção 3.1 |
| Primeira resposta em 2 dias úteis | Chamado registrado em canal oficial | Seção 3.2 |

---

## Disposições Gerais

Esta política entra em vigor na data de sua publicação oficial e permanece válida até que uma versão revisada seja publicada em substituição, momento em que a versão anterior perde eficácia imediatamente, ressalvadas as situações em curso devidamente documentadas. Alterações substanciais serão comunicadas aos assinantes do Clube Q+ com antecedência mínima conforme previsto nos termos de uso gerais da plataforma, incorporados a este documento por remissão. Dúvidas sobre a interpretação desta política devem ser direcionadas ao canal oficial de suporte da plataforma, sendo vedada a utilização de canais não oficiais para fins de interpretação normativa.

**Versão** 1.0
**Código do documento** POL CLU 01
**Vigência** a partir da data de publicação oficial

---

## Anexo I. Documentos Referenciados e Remissões Normativas

O presente anexo lista os documentos internos e instrumentos normativos referenciados ao longo desta política, com indicação de sua função e do local onde podem ser consultados.

**POL DEV 03** (Política Geral de Devolução e Reembolso). Documento interno que regulamenta os procedimentos gerais de devolução e reembolso aplicáveis a todos os usuários da plataforma. Referenciado nas Seções 2.3 e 2.4. Disponível na central de documentos da plataforma.

**Termos de Uso Gerais da Plataforma**. Instrumento contratual que rege a relação entre a plataforma e todos os seus usuários, assinantes ou não. Referenciado na seção de Disposições Gerais. Disponível na central de documentos da plataforma.

**Central de Ajuda da Plataforma**. Canal informativo não normativo que contém, entre outros conteúdos, a lista atualizada de categorias de produtos excluídas do benefício de frete grátis. Referenciado na Seção 1.3. Disponível no endereço oficial da plataforma.

> **Nota explicativa.** Em caso de divergência entre o conteúdo deste anexo e o corpo principal desta política, prevalece o disposto no corpo principal. O presente anexo tem caráter meramente orientativo e não altera o conteúdo normativo das seções às quais faz remissão.
