# Como responder disputas, guia do vendedor

## O que é uma disputa

Uma disputa é o mecanismo formal pelo qual o comprador contesta uma transação diretamente na plataforma. Quando isso acontece, a plataforma abre um processo estruturado de análise e o vendedor parceiro precisa agir dentro do prazo estabelecido. Ignorar ou atrasar a resposta não é opção.

---

## O que acontece quando você recebe uma notificação de disputa

Você será notificado pelo painel assim que o comprador abrir o processo. A partir desse momento, o prazo de resposta começa a correr. Não existe prorrogação automática. Não existe aviso de último minuto enviado pela plataforma para lembrar você de agir.

Leia a notificação com atenção. Identifique o pedido envolvido, o motivo declarado pelo comprador e o que ele está solicitando como resolução. Só depois de entender o contexto você deve reunir as evidências.

---

## Documentos obrigatórios para responder

Você precisa anexar no painel os seguintes itens.

- Nota fiscal do pedido
- Comprovante de postagem
- Fotos da expedição

Esses três documentos formam o conjunto mínimo aceitável. A ausência de qualquer um deles enfraquece sua defesa e aumenta a probabilidade de decisão favorável ao comprador.

---

## Como anexar as evidências

Acesse o painel, localize a disputa pelo número do pedido e use a função de upload disponível na tela de resposta. Anexe cada arquivo individualmente. Certifique-se de que os arquivos estão legíveis, sem cortes, sem borrões e com as informações do pedido visíveis.

A palavra evidências não é apenas um termo técnico aqui. Ela representa o conjunto de provas que a plataforma vai analisar para tomar a decisão. Sem evidências suficientes, a análise fica comprometida e a decisão tende a favorecer a parte que apresentou mais documentação.

Formatos aceitos dependem das configurações do painel no momento do envio. Verifique antes de fazer o upload para não perder tempo com arquivos rejeitados.

---

## Prazo de resposta

Perder o prazo de resposta gera decisão pela versão do comprador.

Isso significa que a plataforma encerra o processo sem considerar sua defesa, independentemente de você ter razão sobre o mérito da disputa. O prazo é fixo e não admite exceções operacionais como falta de acesso ao painel, ausência do responsável ou problemas técnicos de terceiros.

Organize sua operação para que sempre haja alguém com acesso ao painel e autoridade para responder disputas. Se você opera sozinho, configure alertas no dispositivo que você usa com mais frequência. A responsabilidade de cumprir o prazo é inteiramente sua.

---

## Penalidades por descumprimento

O descumprimento do prazo ou a apresentação de documentação insuficiente geram consequências diretas e progressivas.

- Decisão automática favorável ao comprador quando o prazo vence sem resposta
- Impacto negativo no histórico de disputas da loja
- Risco de perda do selo da loja conforme o acúmulo de disputas não respondidas ou perdidas
- Possibilidade de restrições operacionais aplicadas pela plataforma em casos recorrentes

Cada disputa perdida por prazo é registrada no histórico da loja. Esse histórico é consultado pela plataforma nos processos de avaliação de reputação e elegibilidade para programas de benefícios.

---

## Reputação e selo da loja

Manter histórico de disputas baixo preserva a reputação e o selo da loja.

O selo é um indicador público de confiabilidade. Compradores o utilizam como critério de decisão de compra. Perder o selo por acúmulo de disputas mal gerenciadas afeta diretamente sua taxa de conversão, sua visibilidade na plataforma e sua competitividade frente a outros vendedores parceiros.

A reputação não se reconstrói rapidamente. Uma sequência de disputas perdidas por falta de resposta pode levar semanas ou meses de operação impecável para ser compensada nos indicadores da plataforma. O custo de não responder é desproporcional ao esforço de responder corretamente.

---

## Boas práticas para evitar disputas ou vencê-las

Antes de qualquer disputa acontecer, você pode reduzir drasticamente a chance de perder um processo adotando os seguintes hábitos.

- Fotografe todos os pedidos antes de fechar a embalagem, incluindo o produto, a nota fiscal e a embalagem lacrada
- Guarde o comprovante de postagem de cada envio em um local de fácil acesso
- Emita a nota fiscal corretamente com os dados do pedido
- Mantenha os registros organizados por número de pedido para localização rápida em caso de disputa

Se a disputa mesmo assim ocorrer, você já terá as evidências prontas para anexar no painel sem precisar correr atrás de documentos dispersos. Esse preparo reduz o tempo de resposta e aumenta a qualidade da documentação apresentada.

---

## Checklist de resposta a disputas

Use esta lista toda vez que receber uma notificação de disputa.

- Leia a notificação e identifique o pedido e o motivo
- Localize a nota fiscal do pedido
- Localize o comprovante de postagem
- Reúna as fotos da expedição
- Acesse o painel e localize a disputa pelo número do pedido
- Faça o upload de cada documento individualmente
- Confirme que todos os arquivos foram recebidos pelo sistema
- Envie a resposta dentro do prazo

Não pule etapas. Não presuma que um documento dispensável. Cada item da lista tem uma função na construção da sua defesa.

---

## Resumo do que você não pode fazer

Não ignore notificações de disputa. Não envie resposta sem as evidências completas. Não perca o prazo esperando que a situação se resolva sozinha. Não delegue a resposta a alguém sem acesso ao painel e sem os documentos necessários.

A plataforma analisa o que foi apresentado dentro do prazo. Nada mais.
