# Prazos de expedição do vendedor

## Obrigação central

Você tem até **2 dias úteis** para despachar o pedido depois que a plataforma confirmar o pagamento. Esse prazo começa a contar no dia útil seguinte à confirmação. Não existe exceção para volume alto de pedidos, feriados locais não reconhecidos pelo calendário nacional ou problemas internos de estoque. A responsabilidade é inteiramente sua.

---

## O que conta como expedição

Despachar significa gerar o código de rastreamento válido e registrar a coleta ou postagem junto à transportadora. Não basta imprimir a etiqueta. A plataforma monitora o primeiro evento de movimentação logística registrado pela transportadora, e é esse evento que define se você cumpriu ou não o prazo de **2 dias úteis**.

---

## Por que esse prazo existe

A experiência do comprador começa no momento em que o pagamento é aprovado. A partir daí, cada hora conta. Pesquisas internas da plataforma mostram que pedidos despachados dentro do prazo geram avaliações mais altas, menos acionamentos de suporte e maior taxa de recompra. Quando você cumpre o prazo, você protege sua reputação e mantém acesso a benefícios que impactam diretamente sua visibilidade nos resultados de busca.

---

## Consequências do descumprimento

Atenção. O descumprimento reiterado do prazo de expedição gera duas penalidades diretas e automáticas.

- Rebaixamento da reputação na plataforma
- Perda do selo de entrega rápida

O rebaixamento de reputação afeta o posicionamento dos seus anúncios. Vendedores com reputação baixa aparecem menos nas buscas, perdem o destaque em categorias e ficam fora de campanhas promocionais organizadas pela plataforma. A perda do selo de entrega rápida remove um dos principais gatilhos de conversão dos seus anúncios, porque compradores filtram ativamente por esse critério na hora de escolher entre vendedores.

Reiterado significa um padrão identificado ao longo do tempo, não um episódio isolado. Mesmo assim, um único atraso já é registrado no seu histórico e contribui para o cálculo da sua reputação.

---

## Como organizar sua operação

Você precisa estruturar sua rotina de despacho para garantir que nenhum pedido fique parado. Veja os pontos essenciais.

- Confirme diariamente os pedidos com pagamento aprovado, inclusive no primeiro horário do dia
- Mantenha etiquetas e embalagens disponíveis antes de publicar qualquer anúncio
- Acorde com sua transportadora ou agência dos Correios os horários de coleta ou postagem
- Se você vende produtos com prazo de produção, configure corretamente o prazo de manuseio no painel da plataforma antes de ativar o anúncio
- Nunca publique um produto que você não consegue despachar dentro de **2 dias úteis** a partir da confirmação do pagamento

---

## Dias úteis na prática

Dias úteis são os dias de segunda a sexta-feira, excluídos os feriados nacionais. Feriados estaduais e municipais não suspendem o prazo, a menos que a plataforma comunique formalmente uma exceção. Se o pagamento for confirmado em uma sexta-feira, o prazo de **2 dias úteis** termina na terça-feira seguinte, considerando que segunda e terça são dias úteis normais.

---

## Situações que não justificam atraso

A plataforma não aceita as seguintes justificativas para descumprimento do prazo.

- Esquecimento ou falha de sistema interno do vendedor
- Volume inesperado de pedidos
- Férias ou ausência de funcionários
- Falta de embalagem ou insumos
- Problemas com fornecedor do produto

Se você antecipa qualquer uma dessas situações, a ação correta é pausar seus anúncios antes que novos pedidos entrem. Vender e não despachar no prazo é sempre pior do que pausar temporariamente.

---

## Selo de entrega rápida

O selo de entrega rápida é concedido pela plataforma com base no histórico de expedição dentro do prazo. Ele aparece nos seus anúncios e funciona como um diferencial competitivo visível para o comprador. Vendedores com o selo convertem mais porque o comprador interpreta o selo como garantia de agilidade.

Perder o selo exige um período de recuperação. Você precisa manter um histórico consistente de cumprimento do prazo para reconquistar o benefício. Não existe atalho.

---

## Reputação e visibilidade

Sua reputação na plataforma é calculada com base em múltiplos fatores, e o prazo de expedição é um dos principais. Um histórico de atrasos empurra sua pontuação para baixo de forma progressiva. A recuperação é possível, mas lenta.

Vendedores com reputação alta recebem mais exposição orgânica, participam de mais campanhas e têm acesso a funcionalidades exclusivas da plataforma. Manter o prazo de **2 dias úteis** é uma das formas mais diretas de proteger esse acesso.

---

## Resumo das obrigações

- Despachar em até **2 dias úteis** após a confirmação do pagamento
- Registrar o código de rastreamento com movimentação real na transportadora
- Manter estoque e logística alinhados antes de ativar anúncios
- Pausar anúncios quando não for possível cumprir o prazo
- Monitorar diariamente o painel de pedidos

O cumprimento do prazo não é uma sugestão. É uma condição de operação na plataforma.
