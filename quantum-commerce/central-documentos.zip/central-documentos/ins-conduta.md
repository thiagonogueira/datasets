# Código de Conduta

## 1. Princípios Gerais

A plataforma foi construída sobre a premissa de que toda relação comercial, seja entre clientes e vendedores, seja entre usuários e equipes de atendimento, deve ocorrer dentro de um ambiente de respeito mútuo, civilidade e boa-fé. Este documento estabelece as normas de conduta que regem todas as interações realizadas no âmbito da plataforma, sendo de observância obrigatória por todos os usuários cadastrados, independentemente de sua condição ou modalidade de uso.

O presente Código de Conduta não constitui documento acessório ou meramente orientativo. Trata-se de instrumento vinculante, cujas disposições integram os Termos de Uso aceitos no momento do cadastro e produzem efeitos jurídicos e operacionais sobre todas as partes envolvidas.

## 2. Âmbito de Aplicação

As regras aqui descritas aplicam-se a qualquer forma de comunicação mediada pela plataforma, incluindo mensagens trocadas entre compradores e vendedores, interações com canais de suporte e atendimento, avaliações, comentários públicos, solicitações de troca ou devolução, e qualquer outro ponto de contato disponibilizado pelo ambiente digital da plataforma.

A abrangência é intencional e não comporta interpretação restritiva. Condutas inadequadas praticadas em qualquer um desses contextos estão sujeitas às consequências previstas neste documento.

## 3. Padrão de Conduta Esperado

Espera-se de todo usuário que suas interações sejam pautadas pelo respeito à dignidade das demais pessoas envolvidas na relação. Isso significa utilizar linguagem adequada, abster-se de qualquer forma de hostilidade e reconhecer que do outro lado de cada mensagem há um ser humano com direitos e limites a serem respeitados.

Clientes devem tratar vendedores com urbanidade, mesmo em situações de insatisfação com produtos ou serviços. Vendedores devem conduzir suas comunicações com profissionalismo, sem pressionar, intimidar ou constranger compradores. Equipes de atendimento devem ser tratadas com cordialidade, e espera-se que correspondam com igual postura. A reciprocidade é elemento central deste Código.

A plataforma reconhece que conflitos e divergências fazem parte natural do ambiente comercial. A existência de um desentendimento, por si só, não configura violação a este Código. O que se veda é a forma desrespeitosa, agressiva ou discriminatória de conduzir qualquer situação, independentemente do mérito da reclamação ou da legitimidade do interesse em jogo.

## 4. Condutas Vedadas

São expressamente proibidas as seguintes condutas.

| Categoria | Exemplos de conduta vedada |
|---|---|
| Ofensas | Insultos, xingamentos, linguagem degradante |
| Discriminação | Manifestações preconceituosas por raça, gênero, orientação sexual, religião, origem ou qualquer outra característica |
| Assédio | Mensagens repetitivas com caráter intimidatório, ameaças veladas ou explícitas, pressão abusiva |

A enumeração acima é exemplificativa e não exaustiva. Condutas que, embora não listadas, atentem contra a dignidade de qualquer participante da plataforma poderão ser enquadradas nas disposições deste Código, a critério da equipe responsável pela apuração.

## 5. Processo de Apuração

Nenhuma medida restritiva será aplicada de forma sumária ou sem o devido processo interno. Ao tomar conhecimento de uma denúncia ou identificar, por meios próprios de monitoramento, uma possível violação a este Código, a plataforma iniciará procedimento formal de apuração.

Durante esse processo, o usuário investigado será notificado sobre a existência da apuração e terá assegurado o direito de resposta, podendo apresentar sua versão dos fatos, contextualizar a situação e oferecer elementos que a equipe responsável deverá considerar antes de qualquer decisão. O direito de resposta não é uma concessão discricionária da plataforma, mas uma garantia estrutural do processo, sem a qual nenhuma sanção poderá ser aplicada.

A análise levará em conta o histórico do usuário na plataforma, a gravidade da conduta relatada, a existência de registros objetivos da interação e quaisquer outros elementos relevantes trazidos pelas partes. A decisão será comunicada ao usuário ao término da apuração.

## 6. Consequências

A conclusão do processo de apuração pela ocorrência de violação a este Código poderá resultar na suspensão da conta do usuário responsável.

A suspensão encerra temporária ou definitivamente o acesso do usuário a todas as funcionalidades da plataforma, conforme a gravidade apurada. Casos de discriminação ou assédio de natureza grave poderão ensejar suspensão permanente, sem possibilidade de reativação da conta.

## 7. Disposições Finais

Este Código de Conduta reflete o compromisso da plataforma com a construção de um ambiente comercial seguro, inclusivo e funcional para todas as pessoas que dele fazem parte. Sua efetividade depende não apenas da atuação da plataforma, mas do engajamento ativo de cada usuário na manutenção de uma cultura de respeito.

Atualizações a este documento poderão ser realizadas pela plataforma sempre que necessário, sendo os usuários informados com antecedência razoável sobre alterações relevantes.
