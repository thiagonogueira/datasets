# Manual de atendimento e resolução de chamados (POL ATD 01)

**Versão 1.0**
**Data de vigência. conforme publicação oficial no painel da plataforma**

---

## Objetivo e âmbito

Este documento estabelece as diretrizes corporativas que regem o atendimento ao cliente e a resolução de chamados na plataforma. As regras aqui descritas aplicam-se a todos os chamados abertos por compradores, vendedores parceiros e lojas oficiais cadastradas, sem distinção de canal de contato ou volume de pedidos envolvido. O cumprimento deste manual é obrigatório para todas as equipes de atendimento, áreas de suporte especializado e prestadores de serviço que atuem em nome da plataforma.

Situações não previstas expressamente neste documento devem ser escaladas ao gestor responsável da área de atendimento para deliberação formal. Nenhuma equipe está autorizada a criar procedimentos paralelos ou a interpretar lacunas de forma autônoma sem esse encaminhamento. A existência de um caso inédito não suspende a obrigação de registrar o chamado e manter o cliente informado enquanto a deliberação ocorre.

Este manual funciona em conjunto com as políticas específicas referenciadas ao longo do texto. Ler apenas este documento sem consultar a POL DEV 03, a POL DIS 04, a POL AUT 02 e a POL PRO 05 gera lacunas de entendimento que comprometem a qualidade do atendimento e expõem a plataforma a inconsistências operacionais.

---

## Definições

Os termos a seguir são utilizados ao longo deste documento com os significados indicados. A equipe deve dominar essas definições antes de operar qualquer fila de chamados.

**Chamado** é o registro formal de uma solicitação, reclamação ou dúvida aberta por um usuário na plataforma.

**Número de protocolo** é o identificador único gerado automaticamente pelo sistema no momento da abertura de cada chamado.

**Classe de assunto** é a categoria atribuída ao chamado que determina a área responsável pelo tratamento e o prazo de primeira resposta aplicável.

**Vendedor parceiro** é o vendedor independente que utiliza a infraestrutura da plataforma para comercializar seus produtos.

**Loja oficial** é a loja operada diretamente por uma marca ou fabricante dentro da plataforma, com condições de atendimento diferenciadas.

**Prazo prometido** é a data de entrega informada no anúncio no momento da compra.

**Área de prevenção** é o setor interno responsável pela apuração de condutas suspeitas de má-fé por parte de vendedores ou compradores.

**Área de autenticidade** é o setor responsável pela verificação da genuinidade de produtos comercializados na plataforma.

**Área de conformidade** é o setor responsável pela aplicação das regras sobre itens de venda não permitida.

Sempre que este manual mencionar uma dessas áreas, a referência diz respeito exclusivamente ao setor interno com essa denominação, e não a qualquer agente externo ou prestador terceirizado.

---

## Seção 1. Princípios do atendimento

Todo chamado recebe um número de protocolo e uma classe de assunto no momento do registro. Esses dois elementos são a base de toda a operação de atendimento e nenhuma ação pode ser tomada sobre um chamado que não os possua.

A classe de assunto define a área responsável pelo tratamento do chamado e o prazo de primeira resposta que deve ser observado pela equipe. Classificar errado um chamado não é um erro menor. Uma classificação incorreta pode colocar o chamado na fila errada, atrasar a resposta ao cliente e gerar descumprimento de prazo mesmo quando a equipe agiu com rapidez.

Cada chamado trata de um único assunto. Quando a mensagem do cliente traz mais de um assunto, o atendimento registra um chamado para cada um deles de forma separada. Imagine, por exemplo, um comprador que abre contato relatando ao mesmo tempo que o produto chegou com defeito e que suspeita que o vendedor agiu de má-fé ao descrever o item. Esses são dois chamados distintos, com classes de assunto diferentes, áreas responsáveis diferentes e prazos diferentes. Tratá-los como um só compromete a rastreabilidade e a qualidade da resolução.

O número de protocolo deve ser comunicado ao cliente imediatamente após a abertura do chamado, por meio do canal utilizado para o contato.

Nenhum chamado pode ser encerrado sem que o usuário tenha recebido ao menos uma resposta formal da área responsável. O descumprimento dos prazos de primeira resposta estabelecidos neste manual deve ser reportado ao gestor da área no mesmo dia em que o prazo for ultrapassado.

---

## Seção 2. Chamados de entrega

**2.1 Verificação inicial**

Ao receber um chamado relacionado à entrega de um pedido, o atendimento verifica o rastreio e o prazo prometido no anúncio antes de qualquer outra ação. Essa verificação não é opcional e não pode ser substituída por qualquer outra etapa.

**2.2 Pedido dentro do prazo**

Pedido dentro do prazo prometido recebe orientação de acompanhamento, com indicação dos canais de rastreamento disponíveis e estimativa de atualização do status. O atendimento não abre investigação com a transportadora enquanto o prazo prometido não tiver sido ultrapassado.

**2.3 Pedido fora do prazo**

Pedido fora do prazo prometido abre investigação com a transportadora responsável pela entrega. Os prazos de resposta ao cliente durante essa investigação variam conforme o tipo de vendedor envolvido.

- Para vendas realizadas por vendedores parceiros, o prazo de resposta ao cliente na investigação com a transportadora é de 7 dias úteis.
- Para vendas realizadas por lojas oficiais, o prazo de resposta ao cliente na investigação com a transportadora é de 3 dias úteis.

Durante o período de investigação, o atendimento deve manter o cliente informado sobre o andamento do caso, sem comprometer prazos ou resultados antes da conclusão da apuração. Informar o cliente que a investigação está em curso é obrigatório. Antecipar conclusões antes de tê-las é proibido.

---

## Seção 3. Chamados de produto divergente ou com defeito

Chamados que relatem recebimento de produto diferente do anunciado ou produto com defeito exigem que o cliente anexe fotos do item recebido como condição para o prosseguimento da análise. A ausência de documentação fotográfica pode suspender o andamento do chamado até que o material seja enviado pelo cliente.

Confirmada a divergência ou o defeito pela área responsável, o cliente escolhe entre troca e devolução com reembolso. As opções de troca e devolução com reembolso seguem integralmente a política de trocas, devoluções e ressarcimento (POL DEV 03), incluindo prazos, faixas de valor e tetos estabelecidos naquele documento.

A área de atendimento não pode oferecer condições diferentes das previstas na POL DEV 03 sem autorização expressa da gestão. Isso vale para qualquer forma de comunicação com o cliente, incluindo mensagens informais, respostas automáticas personalizadas e orientações verbais prestadas por telefone ou chat.

---

## Seção 4. Chamados de suspeita de má-fé do vendedor

Esta é uma das seções mais sensíveis deste manual. O atendimento deve compreender com precisão o que fazer, o que não fazer e o que nunca fazer quando um chamado indica suspeita de conduta fraudulenta ou má-fé por parte do vendedor.

**O que fazer.**

Chamados que indiquem suspeita de conduta fraudulenta ou má-fé por parte do vendedor são encaminhados à área de prevenção para apuração formal. O procedimento aplicável à apuração segue o disposto na política de disputas (POL DIS 04). O pagamento ao vendedor fica retido durante toda a apuração, sem liberação parcial ou antecipada, até que a área de prevenção emita seu parecer conclusivo.

O valor retido permanece bloqueado independentemente de qualquer solicitação do vendedor durante o período de investigação. Solicitações de liberação antecipada, independentemente do argumento apresentado, não têm amparo neste manual e devem ser respondidas com a informação de que o processo segue seu curso normal.

**O que nunca fazer.**

Pagamento feito fora da plataforma não tem proteção nem reembolso, em nenhuma hipótese. Esta regra é absoluta e não admite exceções, independentemente das circunstâncias relatadas pelo comprador ou pelo vendedor. O atendimento não pode criar expectativa de proteção ou reembolso para pagamentos realizados fora do ambiente da plataforma, mesmo que o cliente apresente comprovantes, relatos detalhados ou qualquer outro tipo de documentação.

A plataforma recomenda formalmente que todos os pagamentos sejam realizados exclusivamente pelos meios disponíveis dentro do ambiente da plataforma, justamente para que o comprador possa contar com os mecanismos de proteção disponíveis. Quando o cliente relata ter pago fora da plataforma, o atendimento registra o chamado, informa a regra com clareza e encaminha à área de prevenção para ciência, sem criar qualquer expectativa de resolução financeira.

---

## Seção 5. Chamados de autenticidade

Chamados que questionem a autenticidade de um produto são encaminhados à área de autenticidade para análise especializada, conforme os procedimentos da POL AUT 02.

O anúncio relacionado ao chamado pode ser suspenso preventivamente enquanto a análise estiver em curso, a critério da área de autenticidade. A suspensão preventiva do anúncio não implica reconhecimento de irregularidade e pode ser revertida caso a análise conclua pela autenticidade do produto.

O vendedor será notificado sobre a suspensão preventiva e terá a oportunidade de apresentar documentação comprobatória dentro do prazo estabelecido pela POL AUT 02.

---

## Seção 6. Chamados sobre item de venda não permitida

Chamados que identifiquem ou denunciem a comercialização de itens de venda não permitida são encaminhados à área de conformidade, que aplica os critérios e procedimentos estabelecidos na lista de itens de venda não permitida (POL PRO 05).

A área de atendimento não tem competência para deliberar sobre a permissão ou proibição de itens, cabendo essa decisão exclusivamente à área de conformidade. O atendimento registra, encaminha e informa o cliente que a análise está em curso. Qualquer declaração sobre o resultado antes da conclusão da análise pela área de conformidade é vedada.

---

## Seção 7. Devolução e reembolso

Todos os processos de devolução e reembolso originados de chamados tratados neste manual seguem a POL DEV 03. A POL DEV 03 estabelece os prazos, as faixas de valor e os tetos aplicáveis a cada situação, e seus termos prevalecem sobre qualquer orientação verbal ou informal prestada pela equipe de atendimento.

Em nenhuma hipótese o atendimento pode comprometer reembolso em condições, valores ou prazos diferentes dos previstos na POL DEV 03.

---

## Seção 8. Disposições gerais

Este manual é revisado periodicamente pela gestão de atendimento e pela área jurídica da plataforma. Alterações neste documento entram em vigor na data publicada oficialmente no painel interno da plataforma, com comunicação prévia às equipes afetadas.

Casos omissos são resolvidos pelo gestor da área de atendimento em conjunto com a área jurídica, e a decisão adotada pode ser incorporada em revisão futura deste documento.

Este manual não substitui as políticas específicas referenciadas ao longo do texto. As políticas POL DEV 03, POL DIS 04, POL AUT 02 e POL PRO 05 devem ser consultadas em conjunto com este documento para a correta aplicação das regras.

O descumprimento das diretrizes deste manual por membros das equipes de atendimento está sujeito às medidas disciplinares previstas no regulamento interno da plataforma.

---

## Perguntas frequentes

**O cliente abriu contato com dois assuntos diferentes na mesma mensagem. Registro um chamado ou dois.**

Dois. Cada assunto gera um chamado separado, com número de protocolo próprio, classe de assunto própria e área responsável própria. A origem comum na mesma mensagem não altera essa regra.

**O cliente não enviou as fotos do produto com defeito. Posso encerrar o chamado.**

Não. O chamado fica suspenso até que o material seja enviado, mas não pode ser encerrado. O cliente deve ser informado de que o chamado está aguardando a documentação fotográfica para prosseguir.

**O vendedor está pedindo a liberação do pagamento que está retido durante a investigação. O que respondo.**

Informa ao vendedor que o valor retido permanece bloqueado durante toda a apuração e que a liberação ocorre somente após o parecer conclusivo da área de prevenção. Nenhuma liberação parcial ou antecipada é possível.

**O comprador pagou fora da plataforma e quer reembolso. O que faço.**

Registra o chamado, informa ao comprador que pagamento feito fora da plataforma não tem proteção nem reembolso, em nenhuma hipótese, e encaminha o caso à área de prevenção para ciência. Não cria nenhuma expectativa de resolução financeira.

**O prazo de primeira resposta venceu e a área responsável ainda não respondeu. O que faço.**

Reporta ao gestor da área no mesmo dia em que o prazo for ultrapassado. Não aguarda o dia seguinte.

**Um cliente perguntou se determinado item pode ser vendido na plataforma. Posso responder.**

Não. A área de atendimento não tem competência para deliberar sobre permissão ou proibição de itens. Registra o chamado e encaminha à área de conformidade, que aplica os critérios da POL PRO 05.

**O anúncio do vendedor foi suspenso preventivamente durante uma análise de autenticidade. O vendedor diz que isso é uma acusação formal. Como respondo.**

Informa ao vendedor que a suspensão preventiva não implica reconhecimento de irregularidade e pode ser revertida caso a análise conclua pela autenticidade do produto. O vendedor será notificado sobre a oportunidade de apresentar documentação comprobatória dentro do prazo estabelecido pela POL AUT 02.

**Encontrei uma situação que este manual não cobre. Posso criar um procedimento próprio para resolver.**

Não. Situações não previstas expressamente neste documento devem ser escaladas ao gestor responsável da área de atendimento para deliberação formal. O chamado continua registrado e o cliente continua sendo informado enquanto a deliberação ocorre.

**Qual é a diferença de prazo entre vendedor parceiro e loja oficial nos chamados de entrega.**

Para vendedores parceiros, o prazo de resposta ao cliente na investigação com a transportadora é de 7 dias úteis. Para lojas oficiais, esse prazo é de 3 dias úteis.

**Uma orientação verbal da equipe pode sobrepor o que está na POL DEV 03.**

Não. Os termos da POL DEV 03 prevalecem sobre qualquer orientação verbal ou informal prestada pela equipe de atendimento, sem exceção.

---

*Documento POL ATD 01. Versão 1.0.*
