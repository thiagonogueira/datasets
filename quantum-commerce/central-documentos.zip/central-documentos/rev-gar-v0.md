# Tabela de garantia por categoria (POL GAR 01)

Versão anterior, vigente até 31/12/2025. Substituída pela tabela vigente.

## Preâmbulo e Apresentação do Instrumento

O presente instrumento normativo, doravante denominado simplesmente "Política" ou "POL GAR 01", é editado pela plataforma no exercício de sua competência regulatória interna e tem por finalidade disciplinar, de forma exaustiva e vinculante, os prazos e condições de garantia aplicáveis às relações de consumo intermediadas por seus canais oficiais de comercialização. A Política integra o conjunto normativo da plataforma e deve ser lida em conjunto com os demais instrumentos regulatórios internos, especialmente a Política de Devolução e Reembolso (POL DEV 02), a Política de Atendimento ao Consumidor (POL ATC 03) e a Política de Lojas Oficiais e Parceiros Certificados (POL LOF 07), cujas disposições são incorporadas por remissão ao presente texto na medida em que com ele guardem compatibilidade. Eventuais conflitos entre a POL GAR 01 e os demais instrumentos serão resolvidos pela equipe jurídica da plataforma, prevalecendo, em regra, a norma mais específica em relação à mais geral. O cumprimento integral desta Política é condição de permanência de vendedores no ecossistema da plataforma e condição de exercício regular dos direitos pelos consumidores que nela realizem pedidos.

---

## Seção 1. Objetivo e Âmbito de Aplicação

### 1.1. Objetivo

Esta Política estabelece os prazos de garantia aplicáveis às compras realizadas na plataforma, definindo as condições, limitações e procedimentos que regem o exercício dos direitos decorrentes de divergência ou defeito verificados nos produtos adquiridos.

### 1.2. Âmbito Subjetivo

A Política se aplica a todos os vendedores cadastrados na plataforma, independentemente de seu porte, natureza jurídica ou modalidade de cadastro, e a todos os consumidores que efetuem pedidos por meio dos canais oficiais da plataforma. O cumprimento das regras aqui descritas é obrigatório para todas as partes envolvidas na transação, não sendo admissível a invocação de ignorância do conteúdo desta Política como fundamento para o descumprimento de qualquer de suas disposições.

### 1.3. Âmbito Objetivo

Do ponto de vista objetivo, a Política incide sobre todas as categorias de produtos comercializados na plataforma, observadas as especificidades previstas na Seção 4 adiante, que trata das exceções e casos especiais. Produtos sujeitos a regimes normativos específicos, como itens regulados por agências governamentais, poderão ter suas condições de garantia complementadas por instrumentos adicionais editados pela plataforma, sem prejuízo da aplicação subsidiária das disposições aqui contidas.

---

## Seção 2. Definições

### 2.1. Garantia da Plataforma

Para os fins desta Política, entende-se por "Garantia da Plataforma" o período durante o qual o consumidor pode solicitar troca ou reembolso em razão de divergência entre o produto recebido e o anunciado, ou em razão de defeito constatado após o recebimento. A Garantia da Plataforma é distinta e independente da garantia legal prevista na legislação consumerista aplicável, bem como da garantia eventualmente oferecida pelo fabricante do produto, conforme disciplinado na Seção 3 desta Política.

### 2.2. Divergência

Entende-se por "Divergência" qualquer diferença verificável entre as características descritas no anúncio e as características do produto efetivamente entregue, incluindo modelo, cor, tamanho e quantidade. A constatação de divergência deve ser acompanhada de evidências documentais aptas a demonstrar a discrepância alegada, nos termos do procedimento previsto na Seção 5.

### 2.3. Defeito

Entende-se por "Defeito" a falha de fabricação ou dano oculto que comprometa o uso normal do produto e que não seja decorrente de mau uso pelo consumidor. O ônus de demonstrar que o defeito não decorre de mau uso incumbe ao consumidor na fase inicial da solicitação, podendo a plataforma, a seu critério, solicitar laudos técnicos ou análises adicionais para subsidiar a decisão.

### 2.4. Direito de Arrependimento

O "Direito de Arrependimento" consiste na faculdade prevista em lei que permite ao consumidor desistir da compra sem necessidade de justificativa. O prazo para exercício desse direito é de sete dias corridos contados do recebimento do produto, independentemente da categoria. O exercício do Direito de Arrependimento segue rito e condições próprios disciplinados na POL DEV 02, sendo que a presente Política não regula tal hipótese, limitando-se a mencioná-la para fins de distinção conceitual.

### 2.5. Data de Recebimento

Entende-se por "Data de Recebimento" a data registrada na confirmação de entrega emitida pela transportadora ou, na ausência desse registro, a data informada pelo consumidor com comprovação adequada. A definição precisa da Data de Recebimento é elemento essencial para a contagem dos prazos estabelecidos nesta Política, razão pela qual o consumidor deve guardar os comprovantes de entrega pelo período mínimo correspondente ao prazo de garantia aplicável à categoria do produto adquirido.

---

## Seção 3. Prazos de Garantia por Categoria

### 3.1. Regra Geral de Contagem

Os prazos estabelecidos nesta Seção são contados a partir da Data de Recebimento do produto, conforme definida no item 2.5 acima. Eles se aplicam exclusivamente a solicitações fundamentadas em Divergência ou Defeito, e não se confundem com o Direito de Arrependimento mencionado no item 2.4, cujo prazo de sete dias corridos corre de forma autônoma e independente.

### 3.2. Tabela de Prazos

A tabela abaixo apresenta os prazos de Garantia da Plataforma organizados por categoria de produto. O consumidor deve identificar a categoria correta do produto adquirido para verificar o prazo aplicável à sua solicitação.

| categoria do produto | prazo de garantia da plataforma |
|---|---|
| brinquedo | 30 dias |
| game | 30 dias |
| livro | 30 dias |
| maquiagem | 30 dias |
| outros | 30 dias |

### 3.3. Consequências do Decurso do Prazo

Solicitações realizadas fora dos prazos indicados na tabela acima não serão aceitas pela plataforma. O consumidor deve abrir o chamado dentro do prazo correspondente à categoria do produto adquirido, sendo que a data de abertura do chamado, e não a data de envio de documentação complementar, é o marco temporal considerado para fins de verificação da tempestividade da solicitação.

---

## Seção 4. Garantia de Fabricante em Lojas Oficiais

### 4.1. Cumulatividade das Coberturas

Produtos comercializados por lojas oficiais credenciadas nos termos da POL LOF 07 somam à Garantia da Plataforma a garantia do fabricante, cujo prazo é indicado no próprio anúncio do produto. Quando houver garantia do fabricante, o consumidor pode acionar qualquer uma das duas coberturas dentro de seus respectivos prazos, observadas as condições específicas de cada uma. A coexistência das duas garantias não amplia nem restringe os direitos previstos nesta Política, funcionando cada cobertura de forma independente dentro de seus próprios limites e condições.

---

## Seção 5. Exceções e Casos Especiais

### 5.1. Exclusões Gerais de Cobertura

Produtos com sinais evidentes de mau uso, violação de lacre pelo consumidor sem registro fotográfico prévio, ou danos causados por agentes externos não são cobertos pela Garantia da Plataforma. A identificação de qualquer dessas hipóteses durante a análise da solicitação implicará o indeferimento do pedido, sem prejuízo de eventual responsabilização do solicitante por informações inverídicas prestadas no chamado.

### 5.2. Regra Específica para a Categoria Maquiagem

Produtos da categoria maquiagem abertos e utilizados somente são elegíveis à garantia em caso de Defeito comprovado, não em caso de insatisfação com o resultado. O prazo aplicável a essa categoria é de 30 dias, conforme indicado na tabela da Seção 3.2, e a comprovação do Defeito deve observar os requisitos documentais previstos na Seção 6.

### 5.3. Regra Específica para Itens Digitais na Categoria Game

Itens digitais vinculados à categoria game seguem o prazo de 30 dias apenas quando entregues em mídia física. Conteúdo digital ativado pelo consumidor está sujeito a análise individual pela equipe de suporte da plataforma, podendo resultar em decisão distinta daquela que seria aplicável à mídia física, a depender das circunstâncias verificadas no caso concreto.

---

## Seção 6. Procedimento de Solicitação

### 6.1. Abertura do Chamado

O consumidor deve acessar a central de atendimento da plataforma e registrar a solicitação dentro do prazo aplicável à categoria do produto, conforme estabelecido na Seção 3. A solicitação deve conter descrição do problema, fotografias do produto e da embalagem e número do pedido. A ausência de qualquer desses elementos poderá ensejar o sobrestamento da análise até o cumprimento integral dos requisitos documentais exigidos.

### 6.2. Prazo de Resposta

A plataforma analisará o caso e comunicará a decisão em até sete dias corridos após o recebimento completo da documentação exigida. O prazo de sete dias corridos é contado a partir da data em que a plataforma confirmar, por meio de comunicação ao consumidor, que a documentação apresentada está completa e apta à análise. Documentação incompleta suspende a contagem desse prazo até sua regularização pelo consumidor.

### 6.3. Recursos e Revisões

Decisões proferidas pela equipe de suporte poderão ser objeto de pedido de revisão pelo consumidor, nos termos e condições previstos na POL ATC 03, não sendo admitido o reexame de solicitações já definitivamente encerradas por decurso de prazo imputável ao próprio consumidor.

---

## Seção 7. Disposições Gerais e Vigência

Esta Política pode ser atualizada periodicamente pela plataforma, mediante publicação da nova versão na central de políticas. Alterações entram em vigor na data de publicação da nova versão, sendo que pedidos realizados antes da atualização seguem as regras vigentes na data da compra. A plataforma recomenda que consumidores e vendedores consultem regularmente a central de políticas para verificar a versão em vigor.

Versão. 1.0

Data de vigência. Conforme publicação oficial na central de políticas da plataforma.

---

## Nota Explicativa 1. Relação entre os Prazos desta Política

Os prazos previstos nesta Política operam em camadas distintas e não se substituem mutuamente. O prazo de sete dias corridos refere-se exclusivamente ao Direito de Arrependimento e independe de qualquer Defeito ou Divergência. Os prazos de 30 dias, 30 dias, 30 dias e 30 dias referem-se à Garantia da Plataforma por categoria e pressupõem a existência de Defeito ou Divergência verificável. A garantia do fabricante, quando existente, acrescenta uma terceira camada de proteção com prazo e condições próprios indicados no anúncio do produto.

## Nota Explicativa 2. Identificação da Categoria Correta

Casos em que o produto adquirido possa ser enquadrado em mais de uma categoria serão resolvidos pela equipe de suporte da plataforma com base na descrição do anúncio vigente na data da compra. O consumidor não pode, unilateralmente, alterar a categoria do produto para se beneficiar de prazo mais extenso.

---

## Anexo I. Resumo Esquemático dos Prazos e Remissões Normativas

O presente Anexo tem caráter meramente informativo e não substitui a leitura integral das seções acima. Em caso de divergência entre o Anexo e o corpo da Política, prevalece o texto das seções.

| categoria | prazo de garantia da plataforma | instrumento complementar aplicável |
|---|---|---|
| brinquedo | 30 dias | POL GAR 01, Seção 3 |
| game (mídia física) | 30 dias | POL GAR 01, Seções 3 e 5.3 |
| game (conteúdo digital ativado) | análise individual | POL GAR 01, Seção 5.3 e POL ATC 03 |
| livro | 30 dias | POL GAR 01, Seção 3 |
| maquiagem | 30 dias | POL GAR 01, Seções 3 e 5.2 |
| outros | 30 dias | POL GAR 01, Seção 3 |
| arrependimento (todas as categorias) | sete dias corridos | POL DEV 02 |
| lojas oficiais (garantia de fabricante) | conforme anúncio | POL LOF 07 e POL GAR 01, Seção 4 |
