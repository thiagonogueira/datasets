# Termos de Uso da Plataforma

## Objetivo e Âmbito

Este documento estabelece as regras que governam o acesso e o uso da plataforma por todos os usuários cadastrados ou em processo de cadastro. As disposições aqui contidas aplicam-se a compradores, vendedores e visitantes que interajam com qualquer funcionalidade disponibilizada pela plataforma, abrangendo desde a simples navegação pelas páginas públicas até a realização de transações comerciais completas entre partes. O cumprimento integral destas regras é condição necessária para a manutenção do acesso aos serviços oferecidos, e a inobservância de qualquer das disposições aqui previstas poderá acarretar consequências que vão desde a restrição temporária de funcionalidades até o encerramento definitivo da conta do usuário infrator.

A plataforma reserva-se o direito de atualizar este documento periodicamente, sendo responsabilidade do usuário acompanhar as versões vigentes. A continuidade do uso dos serviços após qualquer atualização publicada implica a aceitação tácita das novas condições, razão pela qual recomenda-se a leitura atenta deste documento em sua integralidade antes de qualquer interação com o ambiente digital disponibilizado.

É importante compreender, desde o início, que a plataforma opera como um ambiente de intermediação comercial e não como fabricante, distribuidora ou responsável direta pelos produtos anunciados em seu interior. Essa distinção fundamental orienta a interpretação de todas as seções subsequentes e delimita com precisão o alcance das obrigações e das responsabilidades assumidas por cada parte envolvida nas relações que se estabelecem por meio da plataforma.

---

## Seção 1. Definições

Os termos a seguir possuem significado específico dentro deste documento e devem ser interpretados conforme descrito abaixo, prevalecendo essas definições sobre qualquer sentido comum ou técnico que pudesse ser atribuído às mesmas expressões em outros contextos.

**Plataforma.** O ambiente digital que intermedia a compra e a venda de produtos entre usuários, sem ser a fabricante dos produtos anunciados.

**Usuário.** Toda pessoa física ou jurídica que acesse, navegue ou utilize qualquer recurso disponibilizado pela plataforma.

**Conta.** O registro individual criado pelo usuário para acessar as funcionalidades da plataforma.

**Vendedor.** O usuário que anuncia produtos ou serviços por meio da plataforma.

**Comprador.** O usuário que realiza ou manifesta intenção de realizar aquisições por meio da plataforma.

**Dados verdadeiros.** Informações precisas, atuais e verificáveis fornecidas pelo usuário no momento do cadastro ou em atualizações posteriores.

**Maioridade civil.** A condição jurídica reconhecida pela legislação brasileira vigente que habilita uma pessoa a praticar todos os atos da vida civil de forma independente.

**Políticas complementares.** Documentos adicionais publicados pela plataforma que detalham regras específicas sobre temas como privacidade, cancelamentos, disputas e condutas proibidas.

A correta compreensão dessas definições é pressuposto indispensável para a interpretação adequada de todas as obrigações, direitos e restrições descritos nas seções seguintes. Sempre que qualquer desses termos aparecer ao longo deste documento, ainda que em letras minúsculas ou em forma variante gramaticalmente adaptada, deverá ser entendido com o sentido aqui atribuído.

---

## Seção 2. Cadastro e Elegibilidade

### 2.1 Requisito de Maioridade

O cadastro na plataforma exige maioridade civil do solicitante. Trata-se de requisito inafastável, estabelecido em conformidade com a legislação brasileira vigente, que reconhece a maioridade civil como a condição jurídica que habilita uma pessoa a praticar todos os atos da vida civil de forma independente. Usuários que não tenham atingido a maioridade civil estão impedidos de criar uma conta de forma autônoma, e qualquer tentativa nesse sentido será tratada como violação imediata destes termos.

A plataforma poderá solicitar documentação comprobatória a qualquer momento para verificar o cumprimento deste requisito, inclusive de usuários já cadastrados, caso surjam indícios de que a exigência não foi observada no momento do registro. O cadastro realizado em desacordo com esta exigência poderá ser cancelado imediatamente, sem aviso prévio, e sem que tal cancelamento gere qualquer direito de indenização ou ressarcimento em favor do usuário.

### 2.2 Fornecimento de Dados Verdadeiros

O cadastro exige dados verdadeiros em todos os campos obrigatórios do formulário de registro. O usuário é integralmente responsável pela veracidade, precisão e atualização das informações fornecidas, não podendo alegar desconhecimento desta obrigação em nenhuma circunstância. A inserção de dados falsos, incompletos ou desatualizados constitui violação grave destes termos e poderá, a critério exclusivo da plataforma, ensejar a suspensão imediata da conta, o encerramento definitivo do cadastro ou o acionamento das medidas legais cabíveis conforme a legislação brasileira vigente.

A plataforma poderá suspender ou encerrar a conta de qualquer usuário identificado como fornecedor de informações inverídicas, independentemente do estágio em que se encontre o cadastro ou de quaisquer transações em andamento vinculadas àquela conta. Ressalta-se que a responsabilidade pela exatidão dos dados é exclusiva do usuário, não cabendo à plataforma qualquer ônus decorrente de erros, omissões ou falsidades nas informações inseridas.

### 2.3 Atualização Cadastral

O usuário deve manter seus dados cadastrais atualizados durante todo o período em que mantiver uma conta ativa. Alterações em informações essenciais, como endereço, documento de identificação ou dados de contato, devem ser comunicadas à plataforma por meio dos canais disponíveis. A omissão na atualização de dados pode resultar em restrições de acesso a determinadas funcionalidades, especialmente aquelas que dependem da confirmação de identidade ou da localização do usuário para operar de forma adequada e segura.

---

## Seção 3. Natureza e Titularidade da Conta

### 3.1 Caráter Pessoal da Conta

A conta criada pelo usuário é pessoal e intransferível. Cada usuário pode manter apenas uma conta ativa vinculada ao seu documento de identificação, sendo vedada a multiplicação de registros como forma de contornar restrições, ampliar artificialmente a presença na plataforma ou obter vantagens indevidas em relação a outros usuários. A criação de múltiplas contas por um mesmo usuário é vedada, salvo em casos expressamente autorizados pela plataforma mediante solicitação formal devidamente analisada e aprovada.

### 3.2 Responsabilidade pelo Acesso

O usuário é o único responsável por todas as atividades realizadas por meio de sua conta, incluindo compras, vendas, publicação de anúncios, interações com outros usuários e qualquer outra ação executada a partir das credenciais de acesso vinculadas ao seu registro. O compartilhamento de credenciais de acesso com terceiros é expressamente proibido e configura, por si só, infração a estes termos.

Caso o usuário identifique acesso não autorizado à sua conta, deverá comunicar imediatamente a plataforma por meio dos canais de suporte disponíveis, a fim de que as medidas de segurança cabíveis sejam adotadas sem demora. A plataforma não se responsabiliza por danos decorrentes do uso indevido de credenciais por terceiros quando o usuário tiver contribuído para tal situação por negligência, seja pelo compartilhamento voluntário das informações de acesso, seja pela adoção de práticas inadequadas de segurança digital.

### 3.3 Intransferibilidade

A conta não pode ser cedida, vendida, doada ou transferida a qualquer título para outra pessoa física ou jurídica. Tentativas de transferência de conta serão tratadas como violação grave destes termos e poderão resultar no encerramento imediato de todas as contas envolvidas na operação, sem prejuízo das demais medidas que a plataforma julgue necessárias para preservar a integridade do ambiente e a segurança dos demais usuários.

---

## Seção 4. Papel da Plataforma nas Transações

### 4.1 Intermediação Comercial

A plataforma atua exclusivamente como intermediária nas relações de compra e venda estabelecidas entre compradores e vendedores. Essa característica é central para a compreensão de toda a estrutura de responsabilidades prevista neste documento e nas políticas complementares. A plataforma não é a fabricante dos produtos anunciados em seu ambiente, não participa da cadeia produtiva dos itens comercializados e não integra a relação contratual de compra e venda como parte diretamente obrigada pelo produto ou serviço transacionado.

A relação contratual referente à compra e venda de produtos é estabelecida diretamente entre comprador e vendedor, sendo a plataforma responsável apenas pela infraestrutura que viabiliza essa conexão. Isso significa que as obrigações relativas à entrega, qualidade, garantia e conformidade dos produtos são assumidas pelo vendedor perante o comprador, cabendo à plataforma oferecer os meios tecnológicos e os canais de suporte que tornam possível o encontro entre as partes.

### 4.2 Limitações de Responsabilidade

Por não ser a fabricante dos produtos anunciados, a plataforma não garante a qualidade, autenticidade, segurança ou adequação dos itens comercializados pelos vendedores. Reclamações relativas às características físicas, funcionamento ou conformidade dos produtos devem ser direcionadas primariamente ao vendedor responsável pelo anúncio. A plataforma disponibiliza canais de mediação de disputas para auxiliar na resolução de conflitos entre compradores e vendedores, conforme detalhado nas políticas complementares, mas a existência desses canais não implica assunção de responsabilidade solidária pelos vícios ou defeitos dos produtos.

### 4.3 Anúncios e Conteúdo de Terceiros

O conteúdo dos anúncios publicados pelos vendedores é de responsabilidade exclusiva de quem os publica. A plataforma não endossa, certifica nem valida as informações contidas nos anúncios de terceiros, e a simples disponibilização de um anúncio no ambiente da plataforma não representa qualquer declaração de conformidade, autenticidade ou qualidade por parte da plataforma em relação ao produto ali descrito. A plataforma intermedeia a compra e a venda sem assumir autoria sobre as descrições, imagens ou especificações inseridas pelos vendedores, reservando-se, contudo, o direito de remover conteúdos que violem estes termos ou as políticas complementares.

---

## Seção 5. Aceitação dos Termos e Políticas Complementares

### 5.1 Aceitação pelo Uso

O uso da plataforma implica a aceitação integral destes termos e das políticas complementares vigentes na data de cada acesso. A aceitação ocorre de forma automática a partir do momento em que o usuário utiliza qualquer funcionalidade da plataforma, independentemente de manifestação expressa adicional, de leitura prévia declarada ou de qualquer outro ato formal. Não será admitida alegação de desconhecimento das disposições aqui contidas como justificativa para o descumprimento de qualquer obrigação prevista neste documento.

### 5.2 Políticas Complementares

As políticas complementares fazem parte integrante destes termos e possuem a mesma força vinculante, devendo ser observadas com igual rigor pelo usuário em todas as suas interações com a plataforma. Em caso de conflito aparente entre este documento e uma política complementar, prevalecerá a interpretação que melhor proteja a segurança e a confiança no ambiente da plataforma, podendo a plataforma, a seu critério, editar esclarecimentos ou adendos para dirimir dúvidas interpretativas que venham a surgir.

### 5.3 Recusa dos Termos

O usuário que não concordar com qualquer disposição destes termos ou das políticas complementares deve cessar imediatamente o uso da plataforma e solicitar o encerramento de sua conta pelos canais de suporte disponíveis.

---

## Seção 6. Disposições Gerais

### 6.1 Vigência

Este documento entra em vigor na data de sua publicação e permanece válido até que uma versão revisada seja publicada pela plataforma. A substituição de uma versão por outra não afeta os direitos e obrigações já constituídos durante a vigência da versão anterior, salvo disposição expressa em contrário constante da versão revisada.

### 6.2 Alterações

A plataforma pode alterar estes termos a qualquer momento, sempre que julgar necessário para adequar as regras às mudanças no ambiente operacional, às exigências legais supervenientes ou às necessidades dos usuários. As alterações serão comunicadas aos usuários por meio dos canais oficiais da plataforma com antecedência razoável, permitindo que o usuário tome conhecimento das novas condições antes que estas passem a produzir efeitos plenos. O uso continuado da plataforma após a publicação de alterações constitui aceitação das novas condições, e o usuário que não concordar com as mudanças deverá proceder conforme o disposto na Seção 5.3 deste documento.

### 6.3 Legislação Aplicável

Este documento é regido pela legislação brasileira vigente. Eventuais disputas decorrentes da interpretação ou aplicação destes termos serão submetidas ao foro competente conforme a legislação aplicável, sem prejuízo da utilização prévia dos mecanismos de mediação e resolução de conflitos disponibilizados pela própria plataforma, cuja utilização é incentivada como forma mais ágil e eficiente de solucionar controvérsias antes que estas demandem intervenção judicial.

---

**Versão.** 1.0

**Data de vigência.** Conforme publicação oficial na plataforma.
