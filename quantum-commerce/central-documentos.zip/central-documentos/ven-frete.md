# Política de frete do vendedor

## Responsabilidade pelo custo do frete

O custo do frete segue uma regra simples e direta. em campanhas de frete grátis, quem paga é o vendedor. Em todas as demais vendas, o custo é repassado ao comprador no momento da compra. Não há exceção a essa divisão de responsabilidade.

Você, vendedor parceiro, precisa entender essa distinção antes de cadastrar qualquer produto ou aderir a qualquer campanha promocional na plataforma. Ignorar essa regra gera prejuízo direto no seu repasse e a plataforma não realiza estorno por falta de leitura das políticas vigentes.


## Campanhas de frete grátis

Quando a plataforma ativa uma campanha de frete grátis, a adesão do vendedor implica aceitação automática do custo logístico. Isso significa que o valor do frete será deduzido do seu repasse referente àquele pedido.

Fique atento aos seguintes pontos antes de aderir a uma campanha.

- Verifique o peso e as dimensões dos seus produtos cadastrados.
- Confirme se a margem do produto suporta a absorção do custo de frete.
- Consulte a tabela de frete aplicável à sua região de despacho.
- Não cancele pedidos após aderir à campanha. Cancelamentos indevidos geram penalidade na sua reputação dentro da plataforma.

A adesão a campanhas de frete grátis é voluntária. Uma vez confirmada, não é possível reverter a condição para pedidos já gerados dentro daquela campanha.


## Devoluções e o frete de retorno

Este é um dos pontos que mais gera dúvida entre vendedores parceiros, então leia com atenção.

Quando um pedido é devolvido por desistência do comprador, o valor do frete de retorno é descontado do repasse. Esse desconto é automático e ocorre no ciclo de repasse correspondente ao período em que a devolução foi processada.

O frete de retorno não é negociável e não está sujeito a contestação por parte do vendedor nos casos em que a devolução foi originada por desistência do comprador. A plataforma aplica o desconto com base no valor real do frete de retorno registrado pela transportadora parceira.

Situações que configuram desistência do comprador e que, portanto, geram desconto do frete de retorno no repasse do vendedor.

- Arrependimento dentro do prazo legal.
- Recusa no momento da entrega sem justificativa de defeito.
- Endereço incorreto informado pelo comprador que impossibilitou a entrega.

Situações em que o desconto do frete de retorno não se aplica ao vendedor.

- Produto entregue com defeito comprovado.
- Produto diferente do anunciado, confirmado pela equipe de mediação da plataforma.
- Extravio confirmado pela transportadora durante o trajeto de ida.

Guarde essa distinção. Ela determina se o custo do frete de retorno fica com você ou é absorvido pela plataforma.


## Penalidades por descumprimento

O descumprimento das regras desta política sujeita o vendedor parceiro às seguintes consequências.

- Suspensão temporária da conta em casos de reincidência em cancelamentos pós-campanha.
- Rebaixamento de nível de reputação na plataforma.
- Bloqueio de acesso a campanhas promocionais futuras.

Não há advertência prévia para todos os casos. Algumas infrações geram penalidade imediata.


## Frete subsidiado por volume de vendas

A plataforma oferece ao vendedor a possibilidade de contratar a tabela de frete subsidiado por volume de vendas. Essa modalidade é uma vantagem operacional significativa para vendedores que mantêm alto giro de produtos e precisam de previsibilidade no custo logístico.

Para ter acesso à tabela de frete subsidiado, o vendedor precisa cumprir os critérios de volume estabelecidos pela plataforma no período de apuração vigente. Os critérios são divulgados na área do vendedor e podem ser atualizados a cada ciclo de apuração. A contratação é feita diretamente pelo painel do vendedor, na seção de configurações logísticas.

A tabela de frete subsidiado por volume de vendas não é aplicada retroativamente. Pedidos gerados antes da contratação seguem a tabela padrão vigente no momento do pedido.

Vantagens práticas da tabela subsidiada.

- Redução do custo por envio em rotas de maior demanda.
- Maior competitividade em campanhas de frete grátis, já que o custo absorvido pelo vendedor é menor.
- Previsibilidade orçamentária para planejamento de estoque e precificação.

Se você ainda não avaliou a tabela de frete subsidiado por volume de vendas, acesse o painel do vendedor e compare os valores com a tabela padrão aplicada hoje aos seus pedidos. A diferença pode impactar diretamente sua margem.


## Resumo operacional

Use esta referência rápida no dia a dia.

| Situação | Quem paga o frete |
|---|---|
| Venda comum fora de campanha | Comprador |
| Campanha de frete grátis | Vendedor |
| Devolução por desistência do comprador | Vendedor (frete de retorno descontado do repasse) |
| Devolução por defeito comprovado | Plataforma |

Mantenha esta política consultada regularmente. A plataforma pode atualizar condições logísticas e de campanha, e o vendedor parceiro é responsável por se manter informado por meio do painel e dos comunicados oficiais disponibilizados na área do vendedor.
