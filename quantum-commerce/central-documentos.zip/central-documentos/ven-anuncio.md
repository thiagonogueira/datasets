# Regras de Anúncio para Vendedores

## Para quem este guia se aplica

Este guia é para você, vendedor parceiro cadastrado na plataforma. Não importa o plano de assinatura que você contratou, a categoria do seu produto ou o volume de vendas que você realiza. As regras aqui descritas valem para todos, sem exceção.

Cumprir integralmente o que está neste documento é condição necessária para manter seu anúncio ativo e para continuar operando sua conta. Não existe interpretação alternativa. Não existe negociação caso a caso.

---

## Definições

Antes de seguir em frente, entenda o significado exato dos termos usados neste guia.

**Anúncio** é qualquer publicação criada por você na plataforma com a finalidade de oferecer um produto para venda.

**Título do anúncio** é o campo de texto principal que identifica o produto e é exibido nos resultados de busca.

**contato externo** é qualquer dado ou referência que permita ao comprador se comunicar com você fora do ambiente da plataforma, incluindo endereços de e-mail, números de telefone, perfis em redes sociais, nomes de aplicativos de mensagens e endereços de sites de terceiros.

**Produto usado** é qualquer item que já tenha sido utilizado por você ou por terceiros antes de ser colocado à venda.

**Termos de urgência** são expressões que criam pressão artificial sobre o comprador, tais como "última unidade", "só hoje", "corre" e similares.

---

## 1. Título do Anúncio

### 1.1 O que o título precisa fazer

O título existe para identificar o produto. Só isso. Ele precisa ser claro, preciso e descritivo o suficiente para que o comprador entenda o que está sendo vendido antes mesmo de abrir o anúncio.

Expressões que simulem escassez artificial ou que induzam pressa na decisão de compra são vedadas em qualquer parte do título.

### 1.2 O que pode entrar no título

Você pode usar os seguintes elementos.

- Nome do produto
- Marca
- Modelo
- Capacidade
- Cor
- Outras características técnicas relevantes

Informações promocionais que não descrevam o produto em si não devem compor o título. Frases como "melhor preço", "imperdível" ou "oferta relâmpago" não pertencem ao título e serão tratadas como violação desta seção.

---

## 2. Fotografias

### 2.1 Mostre o que você vai entregar

As fotos precisam mostrar o item real que está sendo vendido. Ponto final.

É vedado utilizar imagens ilustrativas, fotografias de catálogo de terceiros ou imagens que representem um produto diferente do que será entregue ao comprador.

### 2.2 Qualidade mínima exigida

As imagens precisam permitir que o comprador visualize o estado e as características do produto com clareza. Fotografias com baixa resolução que impeçam a identificação do item podem ser removidas pela plataforma sem aviso prévio.

Antes de publicar, verifique os seguintes pontos.

- A imagem está nítida e bem iluminada.
- O produto aparece inteiro, sem cortes que escondam partes relevantes.
- O estado de conservação do item é visível.
- Nenhuma sobreposição de texto ou logotipo de terceiros aparece na foto.

---

## 3. Vedação de contato externo

Esta é a regra mais rigorosa do guia. Leia com atenção.

### 3.1 A proibição

É vedado incluir contato externo em qualquer campo do anúncio. A proibição abrange o título, a descrição, as fotografias, os atributos personalizados e qualquer outro campo disponível no formulário de publicação.

### 3.2 Formas disfarçadas também são violação

A vedação de contato externo se aplica independentemente do formato em que a informação seja inserida. Veja os casos que também configuram violação.

- Número de telefone escrito por extenso (exemplo. "oito, um, um, dois, três...")
- E-mail fragmentado entre diferentes campos do anúncio
- Perfil de rede social inserido dentro de uma imagem
- Nome de aplicativo de mensagens acompanhado de qualquer identificador do vendedor
- Endereço de site de terceiro mencionado na descrição

Se a informação permite que o comprador entre em contato com você fora da plataforma, ela é contato externo. Não existe zona cinzenta aqui.

### 3.3 Penalidades

Anúncios que contenham contato externo serão removidos pela plataforma. A reincidência pode resultar na suspensão temporária ou no encerramento definitivo da conta do vendedor.

Não há aviso antes da remoção do anúncio. A plataforma age assim que a violação é identificada.

---

## 4. Produtos Usados

### 4.1 Informe a condição primeiro

Se você está vendendo um produto usado, a condição do item precisa aparecer no primeiro parágrafo da descrição. Antes de listar características, antes de falar sobre benefícios, antes de qualquer outra informação, o comprador precisa saber que o produto já foi utilizado.

Esta ordem não é sugestão. É obrigação.

### 4.2 Como redigir a condição

Use linguagem direta. Exemplos de redação adequada.

- "Este produto é usado e apresenta marcas de uso nas laterais."
- "Item seminovo, utilizado por aproximadamente seis meses, sem danos funcionais."
- "Produto usado, com arranhões visíveis na tampa traseira."

Termos vagos como "em bom estado", "conservado" ou "pouco usado" sem nenhuma descrição adicional não atendem ao requisito desta seção. O comprador precisa entender o estado real do produto, não uma avaliação subjetiva sua.

---

## 5. Responsabilidades e Disposições Gerais

Você é integralmente responsável pelo conteúdo publicado em sua conta. A plataforma reserva o direito de remover, pausar ou solicitar a correção de qualquer anúncio que não esteja em conformidade com as regras estabelecidas neste documento, a qualquer momento e sem necessidade de justificativa prévia.

As ações que a plataforma pode tomar incluem as seguintes.

- Remoção imediata do anúncio sem aviso prévio
- Pausa do anúncio com solicitação de correção
- Suspensão temporária da conta
- Encerramento definitivo da conta em casos de reincidência ou violação grave

Dúvidas sobre a aplicação desta política devem ser encaminhadas pelos canais oficiais de atendimento da plataforma. Não tente resolver questões relacionadas a penalidades por outros meios.

---

## Resumo das Obrigações

Use esta lista como checklist antes de publicar qualquer anúncio.

- O título descreve o produto sem termos de urgência.
- As fotos mostram o item real que será entregue.
- Nenhum campo do anúncio contém contato externo em qualquer formato.
- Se o produto é usado, a condição aparece no primeiro parágrafo da descrição, com linguagem clara e objetiva.

---

**Versão** 1.0
**Data de vigência** 1 de janeiro de 2025
