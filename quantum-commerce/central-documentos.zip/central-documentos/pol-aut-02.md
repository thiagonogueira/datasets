# Política de Autenticidade (POL AUT 02)

## Objetivo e Âmbito

Esta política estabelece as regras aplicáveis à autenticidade dos produtos anunciados e comercializados por meio da plataforma. O documento se aplica a todos os vendedores cadastrados, a todos os compradores registrados e a todas as transações realizadas no ambiente da plataforma, independentemente da categoria do produto ou do valor da compra. Isso significa que um anúncio de item de baixo valor está sujeito às mesmas exigências de autenticidade que um produto de alto valor, sem qualquer distinção de tratamento. O cumprimento desta política é obrigatório e não está sujeito a negociação individual entre as partes.

A plataforma atua como intermediária entre compradores e vendedores e, nessa condição, tem o dever de garantir que os anúncios publicados representem fielmente os produtos oferecidos. A comercialização de produtos falsificados ou de imitações apresentadas como itens originais compromete a confiança de toda a comunidade de usuários e expõe as partes envolvidas a consequências legais e contratuais graves. Esse compromisso não é uma preferência operacional, é uma condição estrutural do funcionamento da plataforma.

---

## Definições

Para os fins desta política, os termos abaixo têm os seguintes significados. Recomenda-se a leitura completa desta seção antes de prosseguir, pois os conceitos aqui definidos são referenciados ao longo de todo o documento.

**Produto original.** Item fabricado pelo detentor legítimo da marca ou por fabricante devidamente licenciado, comercializado com autorização expressa do titular dos direitos de propriedade intelectual.

**Imitação.** Qualquer produto que reproduza, total ou parcialmente, a aparência, a marca, o logotipo ou as características de um produto original sem a devida autorização do titular, independentemente do material utilizado ou do grau de semelhança.

**Anúncio.** Publicação realizada pelo vendedor na plataforma contendo descrição, imagens, preço e demais informações relativas ao produto oferecido para venda.

**Área de autenticidade.** Equipe interna da plataforma responsável pela análise de denúncias relacionadas à autenticidade dos produtos comercializados.

**Chamado.** Registro formal aberto pelo comprador por meio dos canais oficiais da plataforma para relatar uma suspeita ou ocorrência relacionada à autenticidade de um produto adquirido.

**Reembolso integral.** Devolução da totalidade do valor pago pelo comprador na transação, incluindo o valor do produto, conforme definido nesta política e referenciado na POL DEV 03.

---

## 1. Compromisso com a Autenticidade

Todo produto anunciado como original deve ser, de fato, original.

Esse princípio é inviolável e representa a base do relacionamento de confiança entre a plataforma, os vendedores e os compradores. Não existe margem de interpretação neste ponto. Um produto que reproduza características de um original sem autorização do titular dos direitos não pode ser anunciado como autêntico, independentemente do quanto se assemelhe ao item legítimo ou de qualquer justificativa comercial apresentada pelo vendedor.

A venda de imitação anunciada como autêntica viola os termos de uso da plataforma e a legislação vigente aplicável à proteção da propriedade intelectual e às relações de consumo. A plataforma não tolera qualquer prática que induza o comprador a acreditar que está adquirindo um produto original quando, na realidade, está recebendo uma imitação. Isso inclui descrições ambíguas, imagens que misturem o produto original com o item vendido, e qualquer outro recurso que, deliberadamente ou não, crie confusão sobre a natureza do item anunciado.

Vendedores que publicarem anúncios com informações falsas sobre a autenticidade de seus produtos estarão sujeitos às penalidades previstas nesta política e nas demais políticas da plataforma, sem prejuízo das medidas legais cabíveis.

---

## 2. Denúncia pelo Comprador

### 2.1 Procedimento de Registro

O comprador que suspeitar de imitação deve registrar um chamado por meio dos canais oficiais de atendimento da plataforma. Não há outro caminho válido para iniciar a investigação. Contatos informais, mensagens diretas para o vendedor ou relatos em outros canais não constituem abertura de chamado para os fins desta política e não ativam os prazos nem os direitos aqui descritos.

O chamado deve conter, obrigatoriamente, os seguintes elementos.

- Fotos da embalagem do produto recebido, incluindo etiquetas, lacres e qualquer elemento de identificação visível.
- Fotos do produto em si, com ângulos suficientes para permitir análise visual adequada.
- Fotos de todos os elementos que motivaram a suspeita de falsificação, como costuras irregulares, logotipos com proporções incorretas, materiais incompatíveis com o padrão do produto original ou ausência de elementos de segurança esperados.
- Identificação do pedido correspondente à transação.

O envio de documentação incompleta pode atrasar a análise. A plataforma poderá solicitar informações adicionais ao comprador durante o processo de investigação, e o prazo de resposta será contado a partir da data em que a documentação completa estiver disponível, não da data do primeiro contato.

### 2.2 Prazo de Resposta

A área de autenticidade responde ao chamado em até 5 dias úteis contados a partir da data de abertura do registro com documentação completa. Esse prazo é aplicável a todos os chamados desta natureza, independentemente da categoria do produto ou do valor da transação.

O prazo de 5 dias úteis se refere à resposta inicial da área de autenticidade e não necessariamente à conclusão de todo o processo de análise, que pode demandar etapas adicionais conforme a complexidade do caso. Um chamado envolvendo um produto com características técnicas específicas, por exemplo, pode exigir consulta a especialistas externos antes que a área de autenticidade emita sua conclusão definitiva. Nesses casos, o comprador será informado sobre o andamento e as etapas pendentes dentro do prazo de 5 dias úteis.

---

## 3. Consequências da Confirmação de Imitação

### 3.1 Direitos do Comprador

Confirmada a imitação pela área de autenticidade, o comprador receberá reembolso integral do valor pago na transação. Esse direito é automático e não depende de nenhuma ação adicional por parte do comprador além do registro do chamado original.

Quando a devolução física do produto for considerada inviável pela plataforma, o reembolso integral será processado sem que o comprador precise devolver o item. Imagine, por exemplo, uma situação em que o custo de envio do produto de volta ao vendedor seja desproporcional ao valor da transação ou em que o item esteja em condições que impossibilitem seu transporte seguro. Nesses casos, a área de autenticidade documenta a inviabilidade e autoriza o processamento do reembolso integral sem exigência de devolução.

A inviabilidade da devolução será avaliada caso a caso pela área de autenticidade, considerando fatores como o custo logístico, o valor do produto e as condições de preservação do item. Essa avaliação é de competência exclusiva da plataforma.

O reembolso integral previsto nesta seção não se sujeita ao teto por faixa estabelecido na POL DEV 03. Essa exceção existe porque a situação de imitação confirmada representa uma violação grave dos termos da plataforma e merece tratamento diferenciado em relação às devoluções convencionais. O comprador que recebeu uma imitação não pode ser penalizado por limites que foram desenhados para situações ordinárias de devolução.

### 3.2 Consequências para o Vendedor

Confirmada a imitação, o anúncio relacionado ao produto será removido imediatamente da plataforma.

O vendedor envolvido será submetido ao fluxo de penalidades vigente, que pode incluir advertência formal, suspensão temporária ou encerramento definitivo da conta, conforme a gravidade e a reincidência da infração. A análise de penalidade considera o histórico completo do vendedor na plataforma, e casos de reincidência tendem a resultar em medidas mais severas desde a primeira avaliação do novo episódio.

---

## 4. Exceções e Casos Especiais

Denúncias que não apresentem evidências suficientes para a conclusão da análise poderão ser arquivadas após comunicação ao comprador. O arquivamento não é definitivo. O comprador poderá reabrir o chamado mediante apresentação de novas evidências, e a análise será reiniciada a partir da data de reabertura com documentação atualizada.

Casos que envolvam litígio judicial em curso serão tratados em conformidade com as orientações da equipe jurídica da plataforma e poderão ter seus prazos suspensos durante o período do processo. Nesses casos, a área de autenticidade e a equipe jurídica atuam de forma coordenada, e o comprador será informado sobre a suspensão e seus motivos.

---

## 5. Disposições Gerais

Esta política deve ser lida em conjunto com a POL DEV 03 e com os termos gerais de uso da plataforma. Em caso de conflito entre documentos, prevalece a disposição mais favorável ao comprador nos casos de imitação confirmada. Essa regra de prevalência garante que nenhuma cláusula de outro documento seja usada para reduzir os direitos do comprador em situações cobertas por esta política.

A plataforma reserva o direito de atualizar esta política periodicamente. Alterações relevantes serão comunicadas aos usuários com antecedência razoável.

**Versão.** POL AUT 02

**Data de vigência.** Conforme publicação oficial na central de políticas da plataforma.

---

## Perguntas Frequentes

**Posso registrar uma suspeita de imitação antes de receber o produto fisicamente?**

Não. O chamado deve ser aberto com base em evidências concretas do produto recebido, incluindo fotos da embalagem e do item. Suspeitas anteriores ao recebimento não constituem base suficiente para abertura de chamado nos termos desta política.

**O prazo de 5 dias úteis começa a contar na data em que abri o chamado?**

O prazo de 5 dias úteis começa a contar a partir da data em que a documentação completa estiver disponível no chamado. Se o chamado for aberto com fotos faltando e a área de autenticidade solicitar complementação, o prazo começa na data em que o comprador enviar os documentos solicitados.

**Se a imitação for confirmada mas eu já tiver descartado o produto, ainda tenho direito ao reembolso integral?**

A análise de viabilidade da devolução é feita pela área de autenticidade caso a caso. A ausência do produto pode dificultar a análise das evidências, por isso é recomendável guardar o item até a conclusão do chamado. Situações específicas serão avaliadas pela equipe responsável.

**O reembolso integral cobre o frete que paguei na compra?**

O reembolso integral corresponde à totalidade do valor pago pelo comprador na transação, conforme definido nesta política e detalhado na POL DEV 03. Para esclarecimentos sobre a composição exata do valor reembolsável, consulte a POL DEV 03.

**O vendedor pode contestar a conclusão da área de autenticidade?**

Sim. O vendedor tem direito a apresentar sua defesa dentro do fluxo de penalidades vigente. A contestação não suspende automaticamente os direitos do comprador já confirmados, e seu processamento segue os procedimentos internos da plataforma.

**O que acontece se eu abrir chamados repetidos sobre o mesmo produto?**

Chamados duplicados sobre a mesma transação serão consolidados pela área de autenticidade. Apenas o registro original será considerado para fins de contagem de prazo. Recomenda-se complementar o chamado existente em vez de abrir um novo registro para o mesmo caso.

**Esta política se aplica a produtos usados anunciados como originais?**

Sim. A condição de uso do produto não altera a obrigação de autenticidade. Um produto usado anunciado como original deve ser, de fato, um item original, ainda que em estado de conservação variável. A falsificação de um produto usado segue as mesmas regras desta política.
