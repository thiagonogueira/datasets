# Procedimento de Disputa e Prevenção (POL DIS 04)

---

## Objetivo e Âmbito

Esta política estabelece as regras e os procedimentos aplicáveis à abertura, à instrução e à resolução de disputas entre clientes e vendedores cadastrados na plataforma, com o propósito central de garantir um ambiente de compras seguro, transparente e justo para todas as partes envolvidas em cada transação realizada sob a intermediação da plataforma.

O presente documento aplica-se a todas as disputas iniciadas a partir da data de vigência indicada na seção de disposições gerais, abrangendo qualquer transação concluída ou em andamento dentro da plataforma, independentemente do canal de venda utilizado pelo vendedor ou do método de pagamento escolhido pelo cliente. A incidência desta política não admite exclusões fundadas em critérios operacionais de natureza comercial ou técnica que não estejam expressamente previstos neste instrumento ou em política complementar devidamente referenciada.

A plataforma atua como intermediária e árbitro final nos processos de disputa, exercendo esse papel exclusivamente com base nas evidências apresentadas por ambas as partes e nas demais informações disponíveis em seus sistemas internos, vedada a consideração de elementos externos não submetidos ao procedimento formal descrito neste documento.

Eventuais conflitos entre as disposições desta política e as regras previstas em outros instrumentos normativos da plataforma serão resolvidos pela aplicação da norma mais específica ao caso concreto, sem prejuízo da consulta à área de prevenção para fins de interpretação.

---

## 1. Definições

Para os fins desta política, os termos abaixo têm os seguintes significados, sendo vedada interpretação extensiva ou analógica que amplie ou restrinja o alcance de qualquer definição sem autorização expressa da plataforma.

**Cliente** é a pessoa física ou jurídica que realiza uma compra por meio da plataforma.

**Vendedor** é a pessoa física ou jurídica cadastrada na plataforma que oferece produtos ou serviços à venda.

**Disputa** é o procedimento formal iniciado pelo cliente para contestar uma transação, um produto recebido ou qualquer outra situação relacionada a um pedido.

**Chamado** é o registro oficial aberto pelo cliente dentro do sistema de atendimento da plataforma, por meio do qual a disputa é formalizada.

**Área de prevenção** é o setor interno da plataforma responsável pela análise, instrução e decisão das disputas abertas.

**Pagamento retido** é o valor correspondente ao pedido em disputa que permanece bloqueado na plataforma durante todo o período de análise, sem ser liberado ao vendedor até que haja uma decisão definitiva.

As definições acima prevalecem sobre quaisquer conceitos adotados em comunicações informais, materiais de marketing ou documentos de suporte que não integrem formalmente o conjunto normativo da plataforma.

---

## 2. Abertura da Disputa

### 2.1 Iniciação pelo Cliente

O processo de disputa tem início exclusivamente por iniciativa do cliente. Para formalizar a disputa, o cliente deve abrir um chamado dentro da plataforma, descrevendo de forma clara e objetiva o ocorrido, com indicação precisa do número do pedido, da data da transação e da natureza da reclamação. Junto à descrição, o cliente deve anexar todas as evidências disponíveis, incluindo fotos do produto recebido, capturas de conversas com o vendedor e quaisquer comprovantes que sustentem a reclamação.

A abertura do chamado por meio de canal não oficial ou por representante sem poderes formalmente constituídos não produz os efeitos previstos nesta política, cabendo ao cliente regularizar a situação pelo canal adequado dentro do prazo que lhe for aplicável.

### 2.2 Qualidade das Evidências

A plataforma recomenda que o cliente forneça o maior volume possível de evidências no momento da abertura do chamado. Evidências adicionadas após a abertura podem ser consideradas, a critério da área de prevenção, desde que apresentadas antes do encerramento do prazo de análise. A área de prevenção não está obrigada a solicitar complementação de evidências, sendo ônus exclusivo do cliente a apresentação de material suficiente para a instrução adequada do chamado.

### 2.3 Restrições à Abertura

Cada chamado de disputa deve estar vinculado a um único pedido. Não é permitido agrupar reclamações de pedidos distintos em um único chamado. A plataforma pode recusar chamados que não atendam aos requisitos mínimos de identificação do pedido e de descrição do ocorrido, sem que essa recusa configure negativa de atendimento, podendo o cliente regularizar e reabrir o chamado observadas as condições desta política.

---

## 3. Retenção do Pagamento

### 3.1 Bloqueio Automático

No momento em que o cliente abre o chamado de disputa, o pagamento ao vendedor é retido de forma automática pelo sistema da plataforma. Esse bloqueio ocorre independentemente do estágio de processamento em que o pagamento se encontra, não sendo necessária qualquer intervenção manual da área de prevenção para que o efeito de retenção se produza.

### 3.2 Duração da Retenção

O valor permanece retido durante todo o período de análise da disputa. A liberação do valor somente ocorre após a decisão definitiva da área de prevenção, conforme descrito na seção 5 desta política. Nenhuma solicitação de liberação antecipada formulada por qualquer das partes será atendida enquanto o chamado estiver em aberto, salvo nas hipóteses de encerramento por desistência formal do cliente nos termos da política POL ATD 01.

### 3.3 Abrangência da Retenção

O valor retido corresponde ao montante total do pedido em disputa, incluindo o valor dos produtos e os custos de frete cobrados na transação. Nenhuma parcela do pagamento é liberada ao vendedor enquanto a disputa estiver em aberto. Em pedidos compostos por múltiplos itens, a retenção recai sobre a integralidade do valor do pedido vinculado ao chamado, ainda que a reclamação do cliente diga respeito a apenas um dos itens que o compõem.

---

## 4. Resposta do Vendedor

### 4.1 Prazo de Resposta

Após a abertura do chamado pelo cliente, o vendedor tem 3 dias úteis para apresentar sua resposta formal dentro da plataforma. Esse prazo é contado a partir da data e hora em que o chamado foi registrado no sistema, sendo de responsabilidade exclusiva do vendedor o acompanhamento das notificações enviadas pela plataforma pelos canais oficiais cadastrados.

### 4.2 Conteúdo da Resposta

A resposta do vendedor deve conter sua versão dos fatos e todas as evidências que considere relevantes para a análise. Evidências válidas incluem comprovantes de envio, registros de rastreamento, fotos do produto antes do envio, capturas de conversas com o cliente e qualquer outro documento pertinente. Respostas que se limitem a contestar a reclamação sem apresentar evidências de suporte terão seu valor probatório avaliado de forma restritiva pela área de prevenção.

### 4.3 Ausência de Resposta

Caso o vendedor não apresente resposta dentro do prazo de 3 dias úteis, a área de prevenção prosseguirá com a análise com base apenas nas evidências apresentadas pelo cliente e nas informações disponíveis nos sistemas internos da plataforma. A ausência de resposta pode ser considerada desfavorável ao vendedor no momento da decisão. O vendedor não poderá alegar cerceamento de defesa em razão de prazo expirado por sua própria inércia.

---

## 5. Análise e Decisão

### 5.1 Prazo de Decisão

A área de prevenção decide em até 10 dias úteis contados da abertura do chamado pelo cliente. Esse prazo engloba o período de resposta do vendedor descrito na seção 4, não sendo reiniciado em razão de qualquer ato praticado pelas partes durante a instrução do chamado.

### 5.2 Critérios de Análise

A decisão é tomada com base nas evidências apresentadas pelas duas partes e no histórico do vendedor dentro da plataforma. O histórico do vendedor inclui o volume de disputas anteriores, o índice de resoluções favoráveis e eventuais registros de comportamento irregular. A área de prevenção pode também considerar padrões sistêmicos identificados nos sistemas internos da plataforma, independentemente de as partes os terem mencionado em suas manifestações.

### 5.3 Comunicação da Decisão

A plataforma comunica a decisão ao cliente e ao vendedor por meio dos canais oficiais de atendimento. A decisão é definitiva no âmbito da plataforma e encerra o processo de disputa referente ao chamado em questão, sem prejuízo do direito de qualquer das partes de buscar as vias extrajudiciais ou judiciais que entender cabíveis, nos termos da legislação aplicável e das disposições da política POL JUR 02.

---

## 6. Consequências da Decisão

### 6.1 Decisão Favorável ao Cliente

Uma decisão favorável ao cliente gera reembolso integral do valor pago, incluindo frete. Nos casos em que o item recebido não corresponde ao produto comprado, o reembolso é concedido sem exigência de devolução do produto ao vendedor. O prazo e o método de devolução do valor ao cliente observarão as regras previstas na política POL FIN 03, que disciplina os procedimentos financeiros de estorno e reembolso aplicáveis às transações realizadas na plataforma.

### 6.2 Decisão Favorável ao Vendedor

Quando a decisão é favorável ao vendedor, o valor retido é liberado integralmente ao vendedor. A plataforma notifica o cliente sobre o encerramento da disputa e os fundamentos da decisão. A liberação observará os ciclos de processamento financeiro previstos na política POL FIN 03, não sendo exigível pelo vendedor em prazo inferior ao ali estabelecido.

### 6.3 Confirmação de Má-Fé do Vendedor

Quando a área de prevenção confirma má-fé por parte do vendedor, a conta do vendedor é suspensa imediatamente. Todos os demais pedidos vinculados ao vendedor suspenso entram automaticamente em verificação pela área de prevenção, que avalia cada um de forma individual antes de autorizar qualquer liberação de pagamento. A suspensão produz efeitos sobre todas as funcionalidades da conta, incluindo a capacidade de listar novos produtos, receber pagamentos e acessar relatórios de desempenho, até que a área responsável conclua a avaliação global da situação do vendedor nos termos da política POL VEN 07.

---

## 7. Casos Especiais e Exceções

### 7.1 Disputas com Alta Complexidade

Em situações de alta complexidade, a área de prevenção pode solicitar informações adicionais a qualquer das partes. O prazo de 10 dias úteis contados da abertura permanece o mesmo, e a solicitação de informações adicionais não suspende nem reinicia esse prazo. As partes devem responder às solicitações da área de prevenção com a maior brevidade possível, sendo que a ausência de resposta tempestiva poderá ser considerada no momento da decisão da forma que a área de prevenção entender mais adequada ao caso concreto.

### 7.2 Produtos Regulamentados

Disputas envolvendo produtos sujeitos a regulamentação específica podem exigir documentação adicional por parte do vendedor. A plataforma pode consultar órgãos externos para subsidiar a decisão, sem que isso altere os prazos previstos nesta política.

### 7.3 Tentativa de Fraude pelo Cliente

Caso a área de prevenção identifique indícios de uso indevido do mecanismo de disputas pelo cliente, a plataforma pode encerrar o chamado e adotar as medidas cabíveis, incluindo restrição de acesso à conta do cliente. A identificação de padrão reiterado de abertura de chamados sem fundamento pode ensejar, adicionalmente, a aplicação das sanções previstas na política POL SEG 05, que trata da prevenção a fraudes e do uso irregular dos mecanismos de proteção ao consumidor disponibilizados pela plataforma. A adoção dessas medidas não afasta a responsabilidade civil ou criminal do cliente perante as autoridades competentes.

---

## 8. Disposições Gerais

Esta política entra em vigor na data de sua publicação oficial pela plataforma e substitui todas as versões anteriores do documento identificado como POL DIS 04.

A plataforma reserva-se o direito de atualizar esta política a qualquer momento, mediante comunicação prévia aos usuários pelos canais oficiais. A versão vigente é sempre a mais recente publicada na central de políticas da plataforma. A continuidade do uso da plataforma após a comunicação de atualização implica a aceitação integral das novas disposições por parte do cliente e do vendedor, nos termos dos instrumentos de adesão firmados no momento do cadastro.

Dúvidas sobre a aplicação desta política devem ser direcionadas à área de atendimento da plataforma por meio dos canais oficiais disponíveis. Interpretações formuladas por canais não oficiais não vinculam a plataforma e não produzem efeitos sobre os procedimentos descritos neste documento.

A presente política deve ser lida em conjunto com as políticas POL ATD 01 (atendimento ao cliente), POL FIN 03 (procedimentos financeiros de estorno e reembolso), POL VEN 07 (gestão e sanções de contas de vendedores), POL SEG 05 (prevenção a fraudes) e POL JUR 02 (orientações sobre vias externas de resolução de conflitos), formando com elas um conjunto normativo integrado e mutuamente complementar.

**Versão** 1.0
**Vigência** a partir da data de publicação oficial

---

## Anexo I. Quadro Resumo de Prazos e Efeitos Procedimentais

O presente anexo integra a política POL DIS 04 para fins de referência rápida, sem substituir nem alterar o conteúdo normativo das seções precedentes. Em caso de divergência entre o quadro abaixo e o texto principal, prevalece o texto principal.

| Etapa | Responsável | Prazo | Efeito Imediato |
|---|---|---|---|
| Abertura do chamado | Cliente | Sem prazo fixo para abertura | Pagamento retido automaticamente |
| Resposta ao chamado | Vendedor | 3 dias úteis | Ausência pode ser considerada desfavorável |
| Decisão da área de prevenção | Área de prevenção | 10 dias úteis contados da abertura | Liberação ou reembolso conforme decisão |
| Suspensão por má-fé | Área de prevenção | Imediata após confirmação | Conta suspensa e pedidos em verificação |

**Nota explicativa 1.** O prazo de 3 dias úteis para resposta do vendedor está contido dentro do prazo global de 10 dias úteis contados da abertura. Os dois prazos correm simultaneamente a partir do registro do chamado no sistema, não de forma sequencial.

**Nota explicativa 2.** O termo retido, empregado nesta política, designa especificamente o bloqueio automático do pagamento no sistema da plataforma, distinto de qualquer medida judicial de indisponibilidade de valores. Os efeitos do pagamento retido são integralmente disciplinados por esta política e pela política POL FIN 03, sem aplicação subsidiária de normas processuais externas.

**Nota explicativa 3.** A contagem de dias úteis observa o calendário oficial aplicável à sede operacional da plataforma, excluídos os sábados, domingos e feriados nacionais reconhecidos. Feriados estaduais e municipais não suspendem a contagem de prazos previstos nesta política, salvo disposição em contrário publicada pela plataforma nos canais oficiais com antecedência mínima razoável.
