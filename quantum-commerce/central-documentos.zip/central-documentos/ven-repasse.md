# Política de repasse e devolução de comissão ao vendedor

---

## Para quem este guia se aplica

Este guia é destinado a todo vendedor parceiro cadastrado e ativo na plataforma. As regras aqui descritas cobrem todas as transações realizadas por meio da plataforma, independentemente da categoria do produto ou da modalidade de entrega utilizada. Não há exceção por volume de vendas, tempo de cadastro ou tipo de conta. Se você vende pela plataforma, este documento é obrigatório e você responde por ele.

---

## Definições que você precisa conhecer

Antes de qualquer coisa, entenda o significado exato dos termos usados neste guia. Confusão com vocabulário gera erros operacionais e, em alguns casos, penalidades financeiras.

**Repasse** é a transferência do valor líquido da venda para a sua conta, depois que a plataforma deduz a comissão devida sobre aquela transação.

**Devolução do repasse** é o processo pelo qual a plataforma restitui ao vendedor valores previamente retidos ou descontados em razão de uma disputa, cancelamento ou devolução de produto. Leia essa definição com atenção porque ela aparece em situações distintas ao longo deste guia e o contexto muda o que você deve fazer.

**Entrega confirmada** é o registro no sistema da plataforma de que o comprador recebeu o produto. Esse registro acontece de duas formas. por confirmação ativa do comprador ou por atualização do código de rastreamento com status de entrega concluída. As duas formas têm o mesmo peso para fins de contagem de prazo.

**Disputa** é o processo formal aberto por comprador ou vendedor para contestar uma transação dentro dos canais oficiais da plataforma. Comunicações fora desses canais não têm validade para fins desta política.

**Comissão** é o percentual ou valor fixo cobrado pela plataforma sobre cada venda concluída, conforme tabela vigente no momento da transação.

---

## 1. Prazo de repasse ao vendedor

### 1.1 Regra geral

O repasse ocorre 14 dias após a entrega confirmada. A contagem começa na data em que o sistema da plataforma registra a confirmação de entrega, não na data em que o produto foi despachado nem na data em que você acredita que o comprador recebeu o item.

Não tente antecipar esse prazo pelos canais de atendimento comuns. A plataforma não processa pedidos de antecipação por essa via.

### 1.2 O que pode segurar o seu repasse

A liberação do valor depende de uma condição. não pode haver nenhuma disputa aberta sobre aquela transação na data prevista para o repasse. Se existir uma disputa em andamento, o valor fica retido até o encerramento formal do processo. Depois que a disputa é encerrada, os prazos desta política voltam a correr normalmente a partir daquele ponto.

Isso significa que o atraso no repasse, quando causado por disputa, não é erro da plataforma. É consequência direta da existência de um processo em aberto. Resolva disputas com agilidade para não comprometer o fluxo de caixa da sua operação.

---

## 2. Devolução do produto pelo comprador

### 2.1 Disputa decidida contra o vendedor

Quando o comprador devolve o produto e a disputa é decidida contra você, a devolução do repasse ao vendedor é integral. Isso quer dizer que o valor total recebido referente àquela transação deverá retornar à plataforma para que o comprador seja reembolsado. A plataforma notificará você sobre a decisão por meio dos canais oficiais de comunicação.

Não espere a notificação para se organizar financeiramente. Sempre que houver uma disputa aberta, considere o valor daquela transação como contingente até o encerramento do processo.

### 2.2 Prazo para cumprir a devolução do repasse

Você tem 10 dias úteis para concluir a devolução do repasse. Esse prazo começa a contar na data de encerramento formal da disputa no sistema da plataforma.

Descumprir esse prazo tem consequência direta e automática. a plataforma poderá reter valores de transações futuras para cobrir o saldo devedor, conforme previsto nos termos de uso. Não há negociação de prazo por canais de atendimento para esse caso específico.

---

## 3. Cancelamento antes do envio

Existem duas situações possíveis aqui e elas têm tratamentos completamente diferentes.

### 3.1 Cancelamento originado pelo comprador

Quando o comprador cancela o pedido antes de o produto ser despachado, a comissão da plataforma é devolvida a você. A condição é clara. o pedido não pode ter sido enviado no momento do cancelamento. A plataforma verificará o status logístico da transação antes de processar qualquer devolução de comissão. Não informe cancelamento antes do envio se o produto já foi despachado. Isso configura inconsistência de dados e pode gerar investigação.

### 3.2 Cancelamento originado pelo vendedor

Se você cancela o pedido depois que o comprador já confirmou a compra, a comissão não é devolvida. A plataforma poderá reter a comissão integralmente e o comprador será reembolsado pelo valor total pago. Cancelamentos frequentes iniciados pelo vendedor também podem acionar revisão do seu cadastro pela equipe de qualidade da plataforma.

---

## 4. Fraude e casos especiais

Transações identificadas como fraudulentas passam por análise individualizada da equipe de segurança da plataforma. Durante esse processo, todos os prazos previstos nesta política ficam suspensos. A plataforma tem o direito de reter valores enquanto a investigação estiver em curso, sem prazo determinado para encerramento.

Se você receber uma notificação de investigação de fraude sobre uma transação, não tente movimentar os valores relacionados nem abra disputas paralelas. Aguarde o contato oficial da equipe de segurança.

---

## 5. Tabela resumo de prazos e condições

| Situação | Prazo | Condição |
|---|---|---|
| Repasse após entrega confirmada | 14 dias | Sem disputa aberta |
| Retenção por disputa em andamento | Indefinido até encerramento | Disputa ativa no sistema |
| Devolução do repasse após disputa decidida contra o vendedor | 10 dias úteis | A partir do encerramento formal da disputa |
| Devolução de comissão por cancelamento do comprador | Processada pela plataforma | Produto não despachado |
| Retenção de comissão por cancelamento do vendedor | Integral | Pedido confirmado pelo comprador |

---

## 6. Penalidades aplicáveis

Fique atento às situações que geram consequências automáticas para a sua conta.

O não cumprimento do prazo de 10 dias úteis para a devolução do repasse resulta em retenção automática de valores em transações futuras.

Cancelamentos recorrentes iniciados pelo vendedor após confirmação do pedido podem gerar revisão de cadastro e restrição operacional.

Inconsistências no status logístico informado pelo vendedor podem acionar processo de investigação interna.

Qualquer tentativa de movimentar valores retidos durante investigação de fraude agrava a situação do cadastro do vendedor junto à plataforma.

---

## 7. Disposições gerais

Esta política entra em vigor na data de sua publicação oficial na central de ajuda da plataforma. Mudanças futuras serão comunicadas com antecedência mínima de 30 dias pelos canais oficiais. Em caso de conflito entre este documento e outros documentos da plataforma, prevalece o de maior especificidade para o tema em questão.

**Versão** 1.0

**Data de vigência** a definir pela plataforma
